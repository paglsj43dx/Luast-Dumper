#!/usr/bin/env python3
"""luast deobfuscator — command line entry point.

    python3 deobf.py input.lua                 # write input.deobf.lua
    python3 deobf.py input.lua -o out.lua
    python3 deobf.py input.lua --report        # analysis summary only
    python3 deobf.py input.lua --strings       # just dump recovered strings
    python3 deobf.py input.lua --keep-dead     # leave anti-tamper code in place
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from luastdeob.crypto import rank_candidates            # noqa: E402
from luastdeob.pipeline import (deobfuscate, dump_program,  # noqa: E402
                                format_report)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        prog="deobf.py", description="Deobfuscate scripts produced by luast.")
    ap.add_argument("input", help="obfuscated .lua / .luau file ('-' for stdin)")
    ap.add_argument("-o", "--output", help="where to write the result "
                    "(default: <input>.deobf.lua)")
    ap.add_argument("--stdout", action="store_true", help="print instead of writing")
    ap.add_argument("--report", action="store_true", help="show the analysis summary")
    ap.add_argument("--strings", action="store_true",
                    help="only list the strings that were recovered")
    ap.add_argument("--candidates", type=int, metavar="N", default=0,
                    help="for each string, also show the top N alternative decryptions")
    ap.add_argument("--keep-dead", action="store_true",
                    help="keep anti-tamper / dead code instead of deleting it")
    ap.add_argument("--raw", action="store_true",
                    help="skip the readability passes (no renaming or for-loop rebuild)")
    ap.add_argument("--debug", action="store_true",
                    help="dump the constant pool and recovered state graph "
                         "(use this when a new sample comes out wrong)")
    ap.add_argument("--rounds", type=int, default=4,
                    help="constant-propagation rounds (default 4)")
    args = ap.parse_args(argv)

    src = sys.stdin.read() if args.input == "-" else \
        Path(args.input).read_text(encoding="utf-8", errors="replace")

    try:
        text, rep = deobfuscate(src, rounds=args.rounds, keep_dead=args.keep_dead,
                                do_polish=not args.raw, debug=args.debug)
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        print("\nhints:", file=sys.stderr)
        print("  * is this really luast output? the first line usually says so",
              file=sys.stderr)
        print("  * a newer luast build may lay things out differently — run with "
              "--debug to see how far the analysis got", file=sys.stderr)
        return 2

    if args.debug:
        print(format_report(rep))
        print()
        print(rep.debug_dump)
        return 0

    if args.strings:
        for d in rep.strings:
            print(f"[state {d.state}] {d.plaintext.decode('latin-1')!r}")
            if args.candidates:
                for sc, k, pt in rank_candidates(d.ciphertext,
                                                 len(d.ciphertext) - len(d.plaintext),
                                                 1597, 51749, args.candidates)[1:]:
                    print(f"    alt  score={sc:+.2f}  {pt.decode('latin-1')!r}")
        return 0

    if args.report:
        print(format_report(rep))
        return 0

    if args.stdout or args.input == "-":
        print(text, end="")
    else:
        out = Path(args.output) if args.output else \
            Path(args.input).with_suffix("").with_suffix(".deobf.lua")
        header = "-- Recovered by luast-deob\n"
        if rep.banner:
            header += f"-- Original banner: {rep.banner}\n"
        header += (f"-- {len(rep.strings)} string(s) decrypted, "
                   f"{rep.branches_folded} opaque branch(es) folded, "
                   f"{rep.tamper_removed + rep.dead_removed} junk statement(s) removed\n\n")
        out.write_text(header + text, encoding="utf-8")
        print(f"wrote {out}")
        print(format_report(rep), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
