"""Pretty-printer: AST -> readable Luau source."""
from __future__ import annotations

from . import ast_nodes as A
from .lexer import KEYWORDS

BINPRI = {
    "or": (1, 1), "and": (2, 2),
    "<": (3, 3), ">": (3, 3), "<=": (3, 3), ">=": (3, 3), "~=": (3, 3), "==": (3, 3),
    "..": (9, 8),
    "+": (10, 10), "-": (10, 10),
    "*": (11, 11), "/": (11, 11), "//": (11, 11), "%": (11, 11),
    "^": (14, 13),
}
UNARY_PRI = 12

_SAFE = {
    ord("\\"): "\\\\", ord('"'): '\\"', 0x07: "\\a", 0x08: "\\b",
    0x0C: "\\f", 0x0A: "\\n", 0x0D: "\\r", 0x09: "\\t", 0x0B: "\\v",
}


def quote(data: bytes) -> str:
    out = ['"']
    for b in data:
        if b in _SAFE:
            out.append(_SAFE[b])
        elif 0x20 <= b < 0x7F:
            out.append(chr(b))
        else:
            out.append("\\%d" % b)
    out.append('"')
    return "".join(out)


def is_ident(s: str) -> bool:
    if not s or s in KEYWORDS:
        return False
    if not (s[0].isalpha() or s[0] == "_"):
        return False
    return all(c.isalnum() or c == "_" for c in s)


def fmt_number(n) -> str:
    if isinstance(n, bool):
        return "true" if n else "false"
    if isinstance(n, int):
        return str(n)
    if n != n:
        return "0/0"
    if n == float("inf"):
        return "math.huge"
    if n == float("-inf"):
        return "-math.huge"
    if n == int(n) and abs(n) < 1e15:
        return str(int(n))
    r = repr(n)
    return r


class Printer:
    def __init__(self, indent: str = "    "):
        self.indent = indent
        self.depth = 0

    # ---------------- expressions ----------------
    def expr(self, e, limit: int = 0) -> str:
        if isinstance(e, A.Nil):
            return "nil"
        if isinstance(e, A.TrueLit):
            return "true"
        if isinstance(e, A.FalseLit):
            return "false"
        if isinstance(e, A.VarArg):
            return "..."
        if isinstance(e, A.Number):
            return fmt_number(e.value)
        if isinstance(e, A.String):
            return quote(e.value)
        if isinstance(e, A.Name):
            return e.name
        if isinstance(e, A.Paren):
            return "(" + self.expr(e.inner) + ")"
        if isinstance(e, A.Index):
            base = self.expr(e.obj, 100)
            if isinstance(e.obj, (A.Number, A.String, A.Table, A.Function)):
                base = "(" + self.expr(e.obj) + ")"
            if isinstance(e.key, A.String):
                k = e.key.value.decode("latin-1")
                if is_ident(k):
                    return f"{base}.{k}"
            return f"{base}[{self.expr(e.key)}]"
        if isinstance(e, A.Call):
            fn = self.expr(e.func, 100)
            if isinstance(e.func, (A.Function, A.Table, A.Number, A.String, A.BinOp, A.IfExpr)):
                fn = "(" + self.expr(e.func) + ")"
            return f"{fn}({', '.join(self.expr(a) for a in e.args)})"
        if isinstance(e, A.MethodCall):
            return (f"{self.expr(e.obj, 100)}:{e.method}"
                    f"({', '.join(self.expr(a) for a in e.args)})")
        if isinstance(e, A.Function):
            return self.function_literal(e)
        if isinstance(e, A.Table):
            return self.table(e)
        if isinstance(e, A.UnOp):
            op = e.op + (" " if e.op == "not" else "")
            s = op + self.expr(e.operand, UNARY_PRI)
            return "(" + s + ")" if limit > UNARY_PRI else s
        if isinstance(e, A.BinOp):
            lp, rp = BINPRI[e.op]
            s = f"{self.expr(e.left, lp - 1)} {e.op} {self.expr(e.right, rp)}"
            return "(" + s + ")" if lp <= limit else s
        if isinstance(e, A.IfExpr):
            parts = []
            for i, (c, v) in enumerate(e.branches):
                kw = "if" if i == 0 else "elseif"
                parts.append(f"{kw} {self.expr(c)} then {self.expr(v)}")
            parts.append(f"else {self.expr(e.orelse)}")
            s = " ".join(parts)
            return "(" + s + ")" if limit > 0 else s
        raise TypeError(f"cannot print expression {type(e).__name__}")

    def table(self, t: A.Table) -> str:
        items = [self.expr(v) for v in t.array_items]
        for k, v in t.hash_items:
            if isinstance(k, A.String) and is_ident(k.value.decode("latin-1")):
                items.append(f"{k.value.decode('latin-1')} = {self.expr(v)}")
            else:
                items.append(f"[{self.expr(k)}] = {self.expr(v)}")
        if not items:
            return "{}"
        one = "{ " + ", ".join(items) + " }"
        if len(one) <= 96:
            return one
        return "{\n" + "".join(f"\t{i},\n" for i in items) + "}"

    def function_literal(self, f: A.Function) -> str:
        """Render an anonymous function *expression*, body included."""
        params = list(f.params)
        if f.is_vararg:
            params.append("...")
        head = f"function({', '.join(params)})"
        self.depth += 1
        body = self.block(f.body, self.depth)
        self.depth -= 1
        pad = self.indent * self.depth
        if not body:
            return head + " end"
        return head + "\n" + "\n".join(body) + "\n" + pad + "end"

    # ---------------- statements ----------------
    def block(self, b: A.Block, depth: int) -> list[str]:
        out: list[str] = []
        saved, self.depth = self.depth, depth
        for st in b.stmts:
            self.depth = depth
            out.extend(self.stat(st, depth))
        self.depth = saved
        return out

    def stat(self, s, depth: int) -> list[str]:
        pad = self.indent * depth
        if isinstance(s, A.Comment):
            return [pad + "-- " + line for line in s.text.splitlines()] or [pad + "--"]
        if isinstance(s, A.LocalAssign):
            lhs = ", ".join(s.names)
            if s.values:
                return [f"{pad}local {lhs} = " + ", ".join(self.expr(v) for v in s.values)]
            return [f"{pad}local {lhs}"]
        if isinstance(s, A.Assign):
            return [pad + ", ".join(self.expr(t) for t in s.targets) + " = " +
                    ", ".join(self.expr(v) for v in s.values)]
        if isinstance(s, A.CompoundAssign):
            return [f"{pad}{self.expr(s.target)} {s.op}= {self.expr(s.value)}"]
        if isinstance(s, A.CallStat):
            return [pad + self.expr(s.call)]
        if isinstance(s, A.Do):
            return [pad + "do"] + self.block(s.body, depth + 1) + [pad + "end"]
        if isinstance(s, A.While):
            return ([f"{pad}while {self.expr(s.cond)} do"] +
                    self.block(s.body, depth + 1) + [pad + "end"])
        if isinstance(s, A.Repeat):
            return ([pad + "repeat"] + self.block(s.body, depth + 1) +
                    [f"{pad}until {self.expr(s.cond)}"])
        if isinstance(s, A.If):
            out = []
            for i, (c, blk) in enumerate(s.branches):
                kw = "if" if i == 0 else "elseif"
                out.append(f"{pad}{kw} {self.expr(c)} then")
                out.extend(self.block(blk, depth + 1))
            if s.orelse is not None:
                out.append(pad + "else")
                out.extend(self.block(s.orelse, depth + 1))
            out.append(pad + "end")
            return out
        if isinstance(s, A.NumericFor):
            head = f"{pad}for {s.var} = {self.expr(s.start)}, {self.expr(s.stop)}"
            if s.step is not None:
                head += ", " + self.expr(s.step)
            return [head + " do"] + self.block(s.body, depth + 1) + [pad + "end"]
        if isinstance(s, A.GenericFor):
            head = (f"{pad}for {', '.join(s.names)} in "
                    f"{', '.join(self.expr(e) for e in s.exprs)} do")
            return [head] + self.block(s.body, depth + 1) + [pad + "end"]
        if isinstance(s, A.FunctionStat):
            if s.is_local:
                head = f"{pad}local function {self.expr(s.target)}"
            else:
                head = f"{pad}function {self.expr(s.target)}"
            params = list(s.func.params)
            if s.is_method and params and params[0] == "self":
                params = params[1:]
            if s.func.is_vararg:
                params.append("...")
            return ([f"{head}({', '.join(params)})"] +
                    self.block(s.func.body, depth + 1) + [pad + "end"])
        if isinstance(s, A.Return):
            if s.values:
                return [pad + "return " + ", ".join(self.expr(v) for v in s.values)]
            return [pad + "return"]
        if isinstance(s, A.Break):
            return [pad + "break"]
        if isinstance(s, A.Continue):
            return [pad + "continue"]
        # bare expression fallback (anonymous function literals etc.)
        return [pad + self.expr(s)]

    def to_source(self, block: A.Block) -> str:
        return "\n".join(self.block(block, 0)) + "\n"


def to_source(node, indent: str = "    ") -> str:
    p = Printer(indent)
    if isinstance(node, A.Block):
        return p.to_source(node)
    return p.expr(node)
