"""Tokenizer for the Luau subset emitted by luast."""
from __future__ import annotations

from dataclasses import dataclass


KEYWORDS = {
    "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
    "if", "in", "local", "nil", "not", "or", "repeat", "return", "then",
    "true", "until", "while",
}

# Longest-first so that '...' beats '..' beats '.', '==' beats '=', etc.
SYMBOLS = [
    "...", "..=", "//=",
    "==", "~=", "<=", ">=", "..", "::", "+=", "-=", "*=", "/=", "%=", "^=", "//",
    "+", "-", "*", "/", "%", "^", "#", "<", ">", "=", "(", ")", "{", "}",
    "[", "]", ";", ":", ",", ".", "?", "|", "&",
]

SIMPLE_ESCAPES = {
    "a": "\a", "b": "\b", "f": "\f", "n": "\n", "r": "\r",
    "t": "\t", "v": "\v", "\\": "\\", '"': '"', "'": "'", "\n": "\n",
}


class LuaSyntaxError(Exception):
    pass


@dataclass
class Token:
    kind: str           # name | number | string | keyword | symbol | eof
    value: object       # str for most, float/int for numbers, bytes for strings
    line: int
    col: int
    raw: str = ""

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"Token({self.kind}, {self.value!r}, line={self.line})"

    def is_(self, kind: str, value=None) -> bool:
        return self.kind == kind and (value is None or self.value == value)


class Lexer:
    def __init__(self, src: str):
        self.src = src
        self.pos = 0
        self.line = 1
        self.col = 1
        self.tokens: list[Token] = []

    # ---------------- helpers ----------------
    def _peek(self, n: int = 0) -> str:
        i = self.pos + n
        return self.src[i] if i < len(self.src) else ""

    def _advance(self, n: int = 1) -> str:
        chunk = self.src[self.pos:self.pos + n]
        for ch in chunk:
            if ch == "\n":
                self.line += 1
                self.col = 1
            else:
                self.col += 1
        self.pos += n
        return chunk

    def _error(self, msg: str):
        raise LuaSyntaxError(f"{msg} at line {self.line}, col {self.col}")

    # ---------------- long brackets ----------------
    def _long_bracket_level(self) -> int | None:
        """If positioned at [=*[ return the level, else None."""
        if self._peek() != "[":
            return None
        n = 1
        while self._peek(n) == "=":
            n += 1
        if self._peek(n) == "[":
            return n - 1
        return None

    def _read_long_bracket(self, level: int) -> str:
        self._advance(level + 2)
        if self._peek() == "\n":
            self._advance()
        close = "]" + "=" * level + "]"
        idx = self.src.find(close, self.pos)
        if idx < 0:
            self._error("unterminated long bracket")
        body = self.src[self.pos:idx]
        self._advance(idx - self.pos)
        self._advance(len(close))
        return body

    # ---------------- scanners ----------------
    def _skip_trivia(self) -> None:
        while self.pos < len(self.src):
            ch = self._peek()
            if ch in " \t\r\n":
                self._advance()
            elif ch == "-" and self._peek(1) == "-":
                self._advance(2)
                lvl = self._long_bracket_level()
                if lvl is not None:
                    self._read_long_bracket(lvl)
                else:
                    while self.pos < len(self.src) and self._peek() != "\n":
                        self._advance()
            else:
                return

    def _read_number(self) -> Token:
        line, col = self.line, self.col
        start = self.pos
        if self._peek() == "0" and self._peek(1) in "xX":
            self._advance(2)
            while self._peek() and (self._peek() in "0123456789abcdefABCDEF_"):
                self._advance()
            raw = self.src[start:self.pos]
            val = int(raw.replace("_", ""), 16)
        elif self._peek() == "0" and self._peek(1) in "bB":
            self._advance(2)
            while self._peek() in "01_":
                self._advance()
            raw = self.src[start:self.pos]
            val = int(raw.replace("_", "")[2:], 2)
        else:
            seen_dot = seen_exp = False
            while True:
                c = self._peek()
                if c.isdigit() or c == "_":
                    self._advance()
                elif c == "." and not seen_dot and not seen_exp:
                    seen_dot = True
                    self._advance()
                elif c in "eE" and not seen_exp:
                    seen_exp = True
                    self._advance()
                    if self._peek() in "+-":
                        self._advance()
                else:
                    break
            raw = self.src[start:self.pos].replace("_", "")
            if seen_dot or seen_exp:
                val = float(raw)
            else:
                val = int(raw)
        return Token("number", val, line, col, self.src[start:self.pos])

    def _read_string(self) -> Token:
        line, col = self.line, self.col
        quote = self._advance()
        out = bytearray()
        while True:
            ch = self._peek()
            if ch == "":
                self._error("unterminated string")
            if ch == quote:
                self._advance()
                break
            if ch == "\\":
                self._advance()
                e = self._peek()
                if e in SIMPLE_ESCAPES:
                    self._advance()
                    out.extend(SIMPLE_ESCAPES[e].encode("latin-1"))
                elif e == "x":
                    self._advance()
                    h = self._advance(2)
                    out.append(int(h, 16))
                elif e == "z":
                    self._advance()
                    while self._peek() in " \t\r\n":
                        self._advance()
                elif e == "u":
                    self._advance()
                    if self._peek() != "{":
                        self._error("malformed \\u escape")
                    self._advance()
                    h = ""
                    while self._peek() != "}":
                        h += self._advance()
                    self._advance()
                    out.extend(chr(int(h, 16)).encode("utf-8"))
                elif e.isdigit():
                    d = ""
                    while len(d) < 3 and self._peek().isdigit():
                        d += self._advance()
                    out.append(int(d) & 0xFF)
                else:
                    self._advance()
                    out.extend(e.encode("latin-1", "replace"))
            else:
                self._advance()
                out.extend(ch.encode("utf-8"))
        return Token("string", bytes(out), line, col)

    def tokenize(self) -> list[Token]:
        while True:
            self._skip_trivia()
            if self.pos >= len(self.src):
                self.tokens.append(Token("eof", None, self.line, self.col))
                return self.tokens
            line, col = self.line, self.col
            ch = self._peek()

            if ch.isalpha() or ch == "_":
                start = self.pos
                while self._peek().isalnum() or self._peek() == "_":
                    self._advance()
                word = self.src[start:self.pos]
                kind = "keyword" if word in KEYWORDS else "name"
                self.tokens.append(Token(kind, word, line, col))
                continue

            if ch.isdigit() or (ch == "." and self._peek(1).isdigit()):
                self.tokens.append(self._read_number())
                continue

            if ch in "\"'":
                self.tokens.append(self._read_string())
                continue

            lvl = self._long_bracket_level()
            if lvl is not None:
                body = self._read_long_bracket(lvl)
                self.tokens.append(Token("string", body.encode("utf-8"), line, col))
                continue

            for sym in SYMBOLS:
                if self.src.startswith(sym, self.pos):
                    self._advance(len(sym))
                    self.tokens.append(Token("symbol", sym, line, col))
                    break
            else:
                self._error(f"unexpected character {ch!r}")


def tokenize(src: str) -> list[Token]:
    return Lexer(src).tokenize()
