"""End-to-end deobfuscation pipeline."""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from . import ast_nodes as A
from .analysis import (apply_pool_shuffle, decrypt_pass, resolve_branches, sccp)
from .cleanup import (dce, find_accumulator, fold_program, strip_tamper,
                      unreachable_sweep)
from .crypto import DEFAULT_MIX, MixSpec, decode_roblox_json_value
from .devirt import devirtualize
from .parser import parse
from .polish import polish
from .printer import to_source
from .structure import structure
from .values import UNKNOWN, Builtin, is_string


@dataclass
class Report:
    banner: str = ""
    consts: int = 0
    states_total: int = 0
    states_reachable: int = 0
    shuffles: int = 0
    branches_folded: int = 0
    tamper_removed: int = 0
    dead_removed: int = 0
    strings: list = field(default_factory=list)
    payloads: list = field(default_factory=list)
    unresolved: list = field(default_factory=list)
    elapsed: float = 0.0
    warnings: list = field(default_factory=list)
    program: object = None          # the Program, for --debug
    debug_dump: str = ""
    stage_counts: dict = field(default_factory=dict)


def _top_level_locals(tree: A.Block) -> set:
    out = set()
    for st in tree.stmts:
        if isinstance(st, A.LocalAssign):
            out.update(st.names)
    return out


def deobfuscate(src: str, *, rounds: int = 4, keep_dead: bool = False,
                do_polish: bool = True, debug: bool = False):
    """Returns (source_text, Report)."""
    t0 = time.time()
    rep = Report()
    for line in src.splitlines()[:5]:
        s = line.strip()
        if s.startswith("--") and "luast" in s.lower():
            rep.banner = s.lstrip("- ").strip()
            break

    tree = parse(src)
    known_locals = _top_level_locals(tree)
    prog = devirtualize(tree)
    rep.consts = len(prog.consts)
    rep.states_total = len(prog.states)

    rep.shuffles = apply_pool_shuffle(prog)

    mix = MixSpec(prog.mix_ops) if len(prog.mix_ops) >= 4 else DEFAULT_MIX
    if len(prog.mix_ops) < 4:
        rep.warnings.append("key-derivation pipeline not recognised; using the "
                            "built-in luast v1.0.1 schedule")
    found = decrypt_pass(prog, mix)
    rep.strings = found
    for d in found:
        if d.ambiguous:
            rep.warnings.append(
                f"string at state {d.state} is under-determined ({d.candidates} keys "
                f"fit a printable plaintext); best guess {d.plaintext!r} — "
                f"re-run with --strings --candidates 10 to see alternatives")
    rep.warnings.extend(prog.warnings)

    for _ in range(rounds):
        sccp(prog)
        rep.branches_folded += resolve_branches(prog)
    fold_program(prog)

    acc = find_accumulator(prog)
    if not keep_dead:
        rep.tamper_removed = strip_tamper(prog, acc)
    for _ in range(rounds):
        sccp(prog)
        resolve_branches(prog)
        fold_program(prog)
    if not keep_dead:
        rep.dead_removed = dce(prog)
    unreachable_sweep(prog)
    rep.states_reachable = len(prog.states)

    # surface any embedded Roblox buffer/JSON payloads we saw in the pool
    for idx, v in prog.consts.items():
        if is_string(v) and v[:1] == b"{" and b'"t"' in v:
            try:
                kind, val = decode_roblox_json_value(v.decode("latin-1", "replace"))
            except Exception as exc:
                rep.warnings.append(f"pool[{idx}]: embedded payload not decoded ({exc})")
                continue
            if kind != "raw":
                rep.payloads.append((idx, kind, val))

    # snapshot before structuring/polish, which rewrite these nodes in place
    if debug:
        rep.debug_dump = dump_program(prog)

    block = structure(prog)
    if do_polish:
        block = polish(block, known_locals)

    rep.program = prog
    text = to_source(block)
    rep.elapsed = time.time() - t0
    return text, rep


def dump_program(prog, max_consts: int = 200) -> str:
    """Human-readable dump of the recovered VM — the tool for new samples."""
    from .printer import to_source as _src
    L = []
    L.append("### prelude aliases")
    for k, v in sorted(prog.prelude.items()):
        L.append(f"    {k:<6} = {v.name}")
    L.append("")
    L.append(f"### dispatcher: state var `{prog.state_var}`, entry state {prog.entry}, "
             f"pool `{prog.table_var}`")
    L.append(f"### key schedule: LCG (mul={prog.lcg[0]}, add={prog.lcg[1]}), "
             f"{len(prog.mix_ops)} mix ops")
    L.append("")
    L.append(f"### constant pool ({len(prog.consts)} entries, post-shuffle)")
    for i in sorted(prog.consts)[:max_consts]:
        v = prog.consts[i]
        L.append(f"    [{i:>4}] {v!r}")
    if len(prog.consts) > max_consts:
        L.append(f"    ... {len(prog.consts) - max_consts} more")
    L.append("")
    live = [s for s in sorted(prog.states) if prog.states[s].reachable]
    L.append(f"### state graph ({len(live)} live states)")
    for sid in live:
        st = prog.states[sid]
        t = st.term
        if t[0] == "goto":
            term = f"goto {t[1]}"
        elif t[0] == "branch":
            term = f"if {_src(t[1])} then goto {t[2]} else goto {t[3]}"
        elif t[0] == "dynamic":
            term = f"goto <dynamic: {_src(t[1])}>"
        else:
            term = "exit"
        L.append(f"  [state {sid}] (raw {st.raw})  ->  {term}")
        for line in _src(A.Block(st.stmts)).rstrip().splitlines():
            L.append("      " + line)
    return "\n".join(L)


def format_report(rep: Report) -> str:
    L = []
    L.append("luast deobfuscator report")
    L.append("=" * 46)
    if rep.banner:
        L.append(f"  banner            : {rep.banner}")
    L.append(f"  constant pool     : {rep.consts} entries")
    L.append(f"  vm states         : {rep.states_total} decoded, "
             f"{rep.states_reachable} live after folding")
    L.append(f"  pool shuffles     : {rep.shuffles} replayed")
    L.append(f"  opaque branches   : {rep.branches_folded} folded")
    L.append(f"  anti-tamper stmts : {rep.tamper_removed} removed")
    L.append(f"  dead stores       : {rep.dead_removed} removed")
    L.append(f"  strings decrypted : {len(rep.strings)}")
    for d in rep.strings:
        flag = "  (!) ambiguous" if d.ambiguous else ""
        L.append(f"      state {d.state:<5} key=0x{d.key:08X}  {d.plaintext!r}{flag}")
    if rep.payloads:
        L.append(f"  embedded payloads : {len(rep.payloads)}")
        for idx, kind, val in rep.payloads:
            if isinstance(val, bytes):
                prev = val[:48].hex()
                L.append(f"      pool[{idx}] {kind} {len(val)} bytes: {prev}"
                         f"{'...' if len(val) > 48 else ''}")
            else:
                L.append(f"      pool[{idx}] {kind}: {val}")
    for w in rep.warnings:
        L.append(f"  warning           : {w}")
    L.append(f"  elapsed           : {rep.elapsed * 1000:.0f} ms")
    return "\n".join(L)
