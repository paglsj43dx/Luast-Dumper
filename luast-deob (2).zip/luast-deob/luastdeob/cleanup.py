"""Simplification passes: fold constants, delete anti-tamper, DCE, renaming."""
from __future__ import annotations

from . import ast_nodes as A
from .analysis import Interp, collect_aliases
from .devirt import Program
from .values import (NIL, UNDEF, UNKNOWN, Builtin, ConstTable, is_number,
                     is_string, truthy)

# Library calls with no observable side effects: safe to delete if unused.
PURE_CALLS = {
    "pcall", "select", "type", "typeof", "tostring", "tonumber", "rawget",
    "rawequal", "rawlen", "ipairs", "pairs", "next", "unpack", "getmetatable",
    "newproxy", "math", "string", "table", "bit32", "buffer", "utf8", "os",
    "debug", "Font", "Vector2", "Vector3", "Vector2int16", "Vector3int16",
    "CFrame", "Color3", "UDim", "UDim2", "Enum", "BrickColor", "coroutine",
    "game", "workspace", "script", "shared",
}
IMPURE_NAMES = {"print", "warn", "error", "require", "loadstring", "assert",
                "setmetatable", "rawset", "collectgarbage", "spawn", "delay"}


def value_to_ast(v, line: int = 0):
    """Turn a concrete value back into an AST literal, if we can."""
    if v is NIL:
        return A.Nil(line=line)
    if v is True:
        return A.TrueLit(line=line)
    if v is False:
        return A.FalseLit(line=line)
    if is_number(v):
        return A.Number(v, line=line)
    if is_string(v):
        return A.String(v, line=line)
    if isinstance(v, Builtin):
        parts = v.name.split(".")
        node = A.Name(parts[0], line=line)
        for p in parts[1:]:
            node = A.Index(node, A.String(p.encode()), True, line=line)
        return node
    return None


class Folder:
    """Rewrites expressions to their constant value wherever one is known."""

    def __init__(self, prog: Program, aliases: set):
        self.prog = prog
        self.aliases = aliases
        self.interp = Interp(prog, aliases)

    def fold_expr(self, e, full):
        if isinstance(e, (A.Nil, A.TrueLit, A.FalseLit, A.Number, A.String, A.VarArg)):
            return e
        v = full(e)
        lit = value_to_ast(v, getattr(e, "line", 0)) if v not in (UNKNOWN, UNDEF) else None
        if lit is not None and not isinstance(v, ConstTable):
            return lit
        # otherwise recurse into children
        if isinstance(e, A.BinOp):
            return A.BinOp(e.op, self.fold_expr(e.left, full),
                           self.fold_expr(e.right, full), line=e.line)
        if isinstance(e, A.UnOp):
            return A.UnOp(e.op, self.fold_expr(e.operand, full), line=e.line)
        if isinstance(e, A.Paren):
            inner = self.fold_expr(e.inner, full)
            if isinstance(inner, (A.Name, A.Number, A.String, A.Index, A.Call,
                                  A.Nil, A.TrueLit, A.FalseLit)):
                return inner
            return A.Paren(inner, line=e.line)
        if isinstance(e, A.Index):
            return A.Index(self.fold_expr(e.obj, full), self.fold_expr(e.key, full),
                           e.dot, line=e.line)
        if isinstance(e, A.Call):
            return A.Call(self.fold_expr(e.func, full),
                          [self.fold_expr(a, full) for a in e.args], line=e.line)
        if isinstance(e, A.MethodCall):
            return A.MethodCall(self.fold_expr(e.obj, full), e.method,
                                [self.fold_expr(a, full) for a in e.args], line=e.line)
        if isinstance(e, A.IfExpr):
            branches = []
            for c, val in e.branches:
                t = truthy(full(c))
                if t is True:
                    return self.fold_expr(val, full)
                if t is False:
                    continue
                branches.append((self.fold_expr(c, full), self.fold_expr(val, full)))
            if not branches:
                return self.fold_expr(e.orelse, full)
            return A.IfExpr(branches, self.fold_expr(e.orelse, full), line=e.line)
        if isinstance(e, A.Table):
            return A.Table([self.fold_expr(x, full) for x in e.array_items],
                           [(self.fold_expr(k, full), self.fold_expr(v, full))
                            for k, v in e.hash_items], line=e.line)
        return e

    def fold_stmt(self, s, env):
        """Fold one statement; returns a list (possibly empty) of statements."""
        _, full = self.interp.make_eval(env)
        out = []
        if isinstance(s, A.LocalAssign):
            out = [A.LocalAssign(s.names, [self.fold_expr(v, full) for v in s.values],
                                 line=s.line)]
        elif isinstance(s, A.Assign):
            tgts = [t if isinstance(t, A.Name) else self.fold_expr(t, full)
                    for t in s.targets]
            out = [A.Assign(tgts, [self.fold_expr(v, full) for v in s.values], line=s.line)]
        elif isinstance(s, A.CompoundAssign):
            out = [A.CompoundAssign(s.op, s.target, self.fold_expr(s.value, full),
                                    line=s.line)]
        elif isinstance(s, A.CallStat):
            out = [A.CallStat(self.fold_expr(s.call, full), line=s.line)]
        elif isinstance(s, A.If):
            branches = []
            for c, blk in s.branches:
                t = truthy(full(c))
                if t is False:
                    continue
                body = self.fold_block(blk, env)
                if t is True and not branches:
                    return body.stmts
                branches.append((self.fold_expr(c, full), body))
            orelse = self.fold_block(s.orelse, env) if s.orelse is not None else None
            if not branches:
                return orelse.stmts if orelse else []
            if all(not b.stmts for _, b in branches) and (orelse is None or not orelse.stmts):
                return []
            out = [A.If(branches, orelse, line=s.line)]
        elif isinstance(s, A.While):
            t = truthy(full(s.cond))
            if t is False:
                return []
            body = self.fold_block(s.body, env)
            if not body.stmts and t is not True:
                return []
            out = [A.While(self.fold_expr(s.cond, full), body, line=s.line)]
        elif isinstance(s, A.NumericFor):
            body = self.fold_block(s.body, env)
            if not body.stmts:
                return []
            out = [A.NumericFor(s.var, self.fold_expr(s.start, full),
                                self.fold_expr(s.stop, full),
                                self.fold_expr(s.step, full) if s.step else None,
                                body, line=s.line)]
        elif isinstance(s, A.GenericFor):
            body = self.fold_block(s.body, env)
            if not body.stmts:
                return []
            out = [A.GenericFor(s.names, [self.fold_expr(e, full) for e in s.exprs],
                                body, line=s.line)]
        elif isinstance(s, A.Do):
            body = self.fold_block(s.body, env)
            return body.stmts
        elif isinstance(s, A.Repeat):
            out = [A.Repeat(self.fold_block(s.body, env),
                            self.fold_expr(s.cond, full), line=s.line)]
        elif isinstance(s, A.Return):
            out = [A.Return([self.fold_expr(v, full) for v in s.values], line=s.line)]
        else:
            out = [s]
        self.interp.exec_stmt(s, env, full)
        return out

    def fold_block(self, blk: A.Block, env: dict) -> A.Block:
        stmts = []
        for s in blk.stmts:
            stmts.extend(self.fold_stmt(s, dict(env)))
        return A.Block(stmts, line=blk.line)


def fold_program(prog: Program) -> None:
    aliases = collect_aliases(prog)
    f = Folder(prog, aliases)
    for st in prog.states.values():
        if not st.reachable:
            continue
        env = dict(st.env_in)
        stmts = []
        for s in st.stmts:
            stmts.extend(f.fold_stmt(s, env))
        st.stmts = stmts
        if st.term[0] == "branch":
            _, full = f.interp.make_eval(env)
            st.term = ("branch", f.fold_expr(st.term[1], full), st.term[2], st.term[3])


# ------------------------------------------------------------------ tamper

def find_accumulator(prog: Program) -> str | None:
    """The anti-tamper checksum: the variable that collects all the `+=` probes."""
    counts: dict[str, int] = {}
    for st in prog.states.values():
        for n in A.walk(st.stmts):
            if isinstance(n, A.CompoundAssign) and isinstance(n.target, A.Name) \
                    and n.op == "+":
                counts[n.target.name] = counts.get(n.target.name, 0) + 1
    if not counts:
        return None
    name, hits = max(counts.items(), key=lambda kv: kv[1])
    return name if hits >= 3 else None


def strip_tamper(prog: Program, acc: str | None) -> int:
    if not acc:
        return 0
    removed = 0
    for st in prog.states.values():
        keep = []
        for s in st.stmts:
            if isinstance(s, A.CompoundAssign) and isinstance(s.target, A.Name) \
                    and s.target.name == acc:
                removed += 1
                continue
            if isinstance(s, A.Assign) and len(s.targets) == 1 and \
                    isinstance(s.targets[0], A.Name) and s.targets[0].name == acc:
                removed += 1
                continue
            keep.append(s)
        st.stmts = keep
    return removed


# --------------------------------------------------------------------- DCE

def _is_pure(e) -> bool:
    for n in A.walk(e):
        if isinstance(n, A.MethodCall):
            return False
        if isinstance(n, A.Call):
            f = n.func
            root = f
            while isinstance(root, A.Index):
                root = root.obj
            if isinstance(root, A.Name):
                if root.name in IMPURE_NAMES:
                    return False
                if root.name not in PURE_CALLS:
                    return False
            else:
                return False
    return True


def _reads(node) -> set:
    """Names read by a statement (assignment targets excluded)."""
    out = set()
    if isinstance(node, A.Assign):
        for t in node.targets:
            if isinstance(t, A.Index):
                out |= _reads(t)
        for v in node.values:
            out |= _reads(v)
        return out
    if isinstance(node, A.LocalAssign):
        for v in node.values:
            out |= _reads(v)
        return out
    if isinstance(node, A.CompoundAssign):
        out |= _reads(node.value)
        if isinstance(node.target, A.Name):
            out.add(node.target.name)
        else:
            out |= _reads(node.target)
        return out
    for n in A.walk(node):
        if isinstance(n, A.Name):
            out.add(n.name)
    return out


def _successor_ids(prog: Program, st) -> list:
    t = st.term
    if t[0] == "goto":
        return [t[1]]
    if t[0] == "branch":
        return [t[2], t[3]]
    return []


def _kills(s) -> set:
    """Variables this statement definitely overwrites (so uses above it die)."""
    if isinstance(s, A.LocalAssign):
        return set(s.names)
    if isinstance(s, A.Assign) and all(isinstance(t, A.Name) for t in s.targets):
        return {t.name for t in s.targets}
    return set()


def dce(prog: Program, protect: set | None = None) -> int:
    """Backward liveness dead-store elimination over the state graph.

    A simple "is this name read anywhere?" test cannot remove luast's tamper
    prologue, because those statements feed *each other* and so keep the whole
    cluster looking live.  Proper backward dataflow sees that no value in the
    cluster ever reaches an observable statement, and deletes all of it.
    """
    protect = set(protect or ())
    total = 0
    for _ in range(12):
        live_in = {sid: set(protect) for sid in prog.states}
        changed = True
        rounds = 0
        while changed and rounds < 500:
            changed = False
            rounds += 1
            for sid, st in prog.states.items():
                if not st.reachable:
                    continue
                live = set(protect)
                for succ in _successor_ids(prog, st):
                    if succ in live_in:
                        live |= live_in[succ]
                if st.term[0] == "branch":
                    live |= _reads(st.term[1])
                for s in reversed(st.stmts):
                    if _is_pure(s):
                        live -= _kills(s)
                    live |= _reads(s)
                if live != live_in[sid]:
                    live_in[sid] = live
                    changed = True

        removed = 0
        for sid, st in prog.states.items():
            if not st.reachable:
                continue
            live = set(protect)
            for succ in _successor_ids(prog, st):
                if succ in live_in:
                    live |= live_in[succ]
            if st.term[0] == "branch":
                live |= _reads(st.term[1])
            keep_rev = []
            for s in reversed(st.stmts):
                names = _written_names(s)
                if names and not (names & live) and _is_pure(s):
                    removed += 1
                    continue
                keep_rev.append(s)
                if _is_pure(s):
                    live -= _kills(s)
                live |= _reads(s)
            st.stmts = list(reversed(keep_rev))
        total += removed
        if removed == 0:
            break
    return total


def _written_names(s) -> set:
    if isinstance(s, A.LocalAssign):
        return set(s.names)
    if isinstance(s, A.Assign):
        return {t.name for t in s.targets if isinstance(t, A.Name)} \
            if all(isinstance(t, A.Name) for t in s.targets) else set()
    if isinstance(s, A.CompoundAssign) and isinstance(s.target, A.Name):
        return {s.target.name}
    return set()


def _writes_only_names(s) -> bool:
    return bool(_written_names(s))


def unreachable_sweep(prog: Program) -> int:
    before = len(prog.states)
    prog.states = {k: v for k, v in prog.states.items() if v.reachable}
    return before - len(prog.states)
