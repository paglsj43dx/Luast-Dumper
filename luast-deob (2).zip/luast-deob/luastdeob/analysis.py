"""Whole-program passes over the recovered state machine."""
from __future__ import annotations

from dataclasses import dataclass

from . import ast_nodes as A
from .consteval import BIT32_OPS, ConstEvaluator
from .crypto import MixSpec, DEFAULT_MIX, decrypt_string, decode_roblox_json_value
from .devirt import Program, State, _builtin_of, _num
from .values import (NIL, UNDEF, UNKNOWN, Builtin, ConstTable, is_number,
                     is_string, norm_num, truthy)


# --------------------------------------------------------------- pool shuffle

def _is_pool_index(e, aliases: set):
    if isinstance(e, A.Index) and isinstance(e.obj, A.Name) and e.obj.name in aliases:
        n = _num(e.key)
        if n is not None:
            return int(n)
    return None


def collect_aliases(prog: Program) -> set:
    """Names that refer to the constant pool (`aX`, plus `local bb = aX`)."""
    aliases = {prog.table_var}
    changed = True
    while changed:
        changed = False
        for st in prog.states.values():
            for n in A.walk(st.stmts):
                if isinstance(n, A.LocalAssign) and len(n.names) == 1 and \
                        len(n.values) == 1 and isinstance(n.values[0], A.Name) and \
                        n.values[0].name in aliases and n.names[0] not in aliases:
                    aliases.add(n.names[0])
                    changed = True
    return aliases


def apply_pool_shuffle(prog: Program) -> int:
    """Replay the `t[a],t[b],... = t[b],t[a],...` permutation onto the pool.

    luast shuffles its constant pool at runtime so that a static reader of
    `K[57]` sees the wrong entry.  The shuffle runs exactly once, in the entry
    state, so we can just execute it and delete it.
    """
    aliases = collect_aliases(prog)
    applied = 0
    order = _state_order(prog)
    for sid in order:
        st = prog.states[sid]
        keep = []
        for s in st.stmts:
            if isinstance(s, A.Assign) and len(s.targets) > 1:
                tgt = [_is_pool_index(t, aliases) for t in s.targets]
                if all(t is not None for t in tgt) and len(s.values) == len(s.targets):
                    src = [_is_pool_index(v, aliases) for v in s.values]
                    if all(v is not None for v in src):
                        snapshot = {i: prog.consts.get(i, UNKNOWN) for i in set(src)}
                        for t, v in zip(tgt, src):
                            prog.consts[t] = snapshot[v]
                        applied += 1
                        continue
            keep.append(s)
        st.stmts = keep
    return applied


def _state_order(prog: Program) -> list:
    """States in breadth-first order from the entry point."""
    out, seen, queue = [], set(), [prog.entry]
    while queue:
        s = queue.pop(0)
        if s in seen or s not in prog.states:
            continue
        seen.add(s)
        out.append(s)
        t = prog.states[s].term
        if t[0] == "goto":
            queue.append(t[1])
        elif t[0] == "branch":
            queue.extend([t[2], t[3]])
    return out


# ------------------------------------------------------------ string decryptor

@dataclass
class DecryptedString:
    state: int
    var: str
    ciphertext: bytes
    plaintext: bytes
    key: int
    seed: int | None
    candidates: int
    ambiguous: bool


def _contains_call(node, names: set) -> bool:
    for n in A.walk(node):
        if isinstance(n, A.Call):
            b = _builtin_of(n.func)
            if b is not None and b.name.split(".")[-1] in names:
                return True
    return False


def _free_assigned(block: A.Block) -> list:
    """Variables assigned inside a block but declared outside it."""
    declared, assigned = set(), []
    for n in A.walk(block):
        if isinstance(n, A.LocalAssign):
            declared.update(n.names)
        elif isinstance(n, A.Assign):
            for t in n.targets:
                if isinstance(t, A.Name):
                    assigned.append(t.name)
    return [a for a in assigned if a not in declared]


def _decryptor_span(stmts: list):
    """Find (start, end) of an inlined decryptor inside a state body.

    The generated shape is a run of `local x = ...` bindings followed by the
    `while true do ... buffer.fromstring(...) ... end` driver loop.
    """
    for i, s in enumerate(stmts):
        if isinstance(s, (A.While, A.Do, A.Repeat)) and _contains_call(s, {"fromstring"}):
            start = i
            while start > 0 and isinstance(stmts[start - 1], A.LocalAssign) \
                    and len(stmts[start - 1].names) == 1:
                start -= 1
            return start, i
    return None


def decrypt_pass(prog: Program, mix: MixSpec) -> list:
    """Replace each inlined decryptor with the plaintext it would produce."""
    aliases = collect_aliases(prog)
    mul, add = prog.lcg
    results = []
    for sid in _state_order(prog):
        st = prog.states[sid]
        for _ in range(8):                       # a state may hold several
            span = _decryptor_span(st.stmts)
            if span is None:
                break
            start, end = span
            chunk = st.stmts[start:end + 1]
            block = A.Block(chunk)
            info = _solve_decryptor(block, prog, aliases, mul, add, mix)
            targets = _free_assigned(A.Block(st.stmts[end:end + 1]))
            if info is None or not targets:
                prog.warnings.append(
                    f"state {sid}: a string decryptor could not be resolved "
                    f"(ciphertext too short to pin the key down) — left in place")
                break
            # the result is whichever of those variables is read after the block
            later = {n.name for n in A.walk(st.stmts[end + 1:]) if isinstance(n, A.Name)}
            var = next((t for t in targets if t in later), targets[0])
            repl = A.LocalAssign([var], [A.String(info.plaintext)], line=chunk[0].line)
            st.stmts = st.stmts[:start] + [repl] + st.stmts[end + 1:]
            results.append(DecryptedString(sid, var, info.ciphertext, info.plaintext,
                                           info.key, info.seed, info.candidates,
                                           info.ambiguous))
    return results


def _solve_decryptor(node: A.Do, prog: Program, aliases: set, mul: int, add: int,
                     mix: MixSpec):
    """Work out (ciphertext, plaintext length) for one inlined decryptor."""
    binds: dict[str, object] = {}

    def lookup(n):
        if n in binds:
            return binds[n]
        if n in aliases:
            return ConstTable(prog.table_var)
        return prog.prelude.get(n, UNKNOWN)

    ev = ConstEvaluator(lookup=lookup,
                        table_get=lambda t, k: prog.consts.get(int(k), UNKNOWN)
                        if is_number(k) else UNKNOWN)
    sub_values = []
    for n in A.walk(node):
        if isinstance(n, A.LocalAssign) and len(n.names) == len(n.values) == 1:
            v = ev.eval(n.values[0])
            binds[n.names[0]] = v
            if isinstance(n.values[0], A.BinOp) and n.values[0].op == "-" and is_number(v):
                sub_values.append(int(v))

    cts = [v for v in binds.values() if is_string(v)]
    if not cts:
        return None
    ct = max(cts, key=len)

    cand_lens = [v for v in sub_values if 0 < v <= len(ct)]
    for v in binds.values():
        if is_number(v) and 0 <= v < len(ct):
            cand_lens.append(len(ct) - int(v))
    seen, ordered = set(), []
    for v in cand_lens:
        if v not in seen:
            seen.add(v)
            ordered.append(v)

    best = None
    for plen in ordered[:12]:
        r = decrypt_string(ct, len(ct) - plen, mul, add, mix)
        if r is None:
            continue
        if best is None or r.score > best.score:
            best = r
    return best


# ---------------------------------------------------------------------- SCCP

class Interp:
    """Abstract interpreter for one state body."""

    def __init__(self, prog: Program, aliases: set):
        self.prog = prog
        self.aliases = aliases

    def make_eval(self, env: dict):
        def lookup(n):
            if n in env:
                return env[n]
            if n in self.aliases:
                return ConstTable(self.prog.table_var)
            if n in self.prog.prelude:
                return self.prog.prelude[n]
            return UNKNOWN

        def table_get(t, k):
            if is_number(k):
                return self.prog.consts.get(int(k), UNKNOWN)
            return UNKNOWN

        ev = ConstEvaluator(lookup=lookup, table_get=table_get)
        base_eval = ev.eval

        def eval_with_calls(e):
            v = base_eval(e)
            if v is not UNKNOWN:
                return v
            if isinstance(e, A.Call):
                b = _builtin_of(e.func)
                name = None
                if b is not None:
                    name = self.prog.prelude[b.name].name if b.name in self.prog.prelude else b.name
                if name in BIT32_OPS:
                    args = [eval_with_calls(a) for a in e.args]
                    if all(is_number(a) for a in args):
                        try:
                            return norm_num(BIT32_OPS[name](*args))
                        except Exception:
                            return UNKNOWN
            return UNKNOWN

        ev.eval_full = eval_with_calls
        return ev, eval_with_calls

    def run(self, st: State, env_in: dict):
        env = dict(env_in)
        ev, full = self.make_eval(env)
        for s in st.stmts:
            self.exec_stmt(s, env, full)
            ev, full = self.make_eval(env)
        return env

    def exec_stmt(self, s, env, full):
        if isinstance(s, A.LocalAssign):
            if len(s.values) == len(s.names):
                for n, v in zip(s.names, s.values):
                    env[n] = full(v)
            else:
                for n in s.names:
                    env[n] = UNKNOWN if s.values else NIL
        elif isinstance(s, A.Assign):
            if len(s.values) == len(s.targets):
                vals = [full(v) for v in s.values]
            else:
                vals = [UNKNOWN] * len(s.targets)
            for t, v in zip(s.targets, vals):
                if isinstance(t, A.Name):
                    env[t.name] = v
                elif isinstance(t, A.Index):
                    idx = _is_pool_index(t, self.aliases)
                    if idx is not None:
                        self.prog.consts[idx] = UNKNOWN
        elif isinstance(s, A.CompoundAssign):
            if isinstance(s.target, A.Name):
                cur = env.get(s.target.name, UNKNOWN)
                rhs = full(s.value)
                if is_number(cur) and is_number(rhs) and s.op in "+-*/%":
                    try:
                        env[s.target.name] = norm_num(
                            {"+": cur + rhs, "-": cur - rhs, "*": cur * rhs,
                             "/": cur / rhs if rhs else UNKNOWN,
                             "%": cur % rhs if rhs else UNKNOWN}[s.op])
                    except Exception:
                        env[s.target.name] = UNKNOWN
                else:
                    env[s.target.name] = UNKNOWN
        elif isinstance(s, (A.CallStat, A.Break, A.Continue, A.Return, A.Comment)):
            pass
        else:
            for n in A.walk(s):
                if isinstance(n, A.Assign):
                    for t in n.targets:
                        if isinstance(t, A.Name):
                            env[t.name] = UNKNOWN
                elif isinstance(n, A.CompoundAssign) and isinstance(n.target, A.Name):
                    env[n.target.name] = UNKNOWN


def meet(a, b):
    if a is UNDEF:
        return b
    if b is UNDEF:
        return a
    if a is UNKNOWN or b is UNKNOWN:
        return UNKNOWN
    if type(a) is type(b) and a == b:
        return a
    return UNKNOWN


def merge_env(dst: dict, src: dict) -> bool:
    changed = False
    for k in set(dst) | set(src):
        a = dst.get(k, UNDEF)
        b = src.get(k, UNDEF)
        m = meet(a, b)
        if m is not a or (k not in dst):
            if dst.get(k, UNDEF) is not m:
                dst[k] = m
                changed = True
    return changed


def sccp(prog: Program) -> dict:
    """Sparse conditional constant propagation across the state graph."""
    aliases = collect_aliases(prog)
    interp = Interp(prog, aliases)
    entry_env: dict[str, object] = {}
    for st in prog.states.values():
        st.env_in = {}
    prog.states[prog.entry].env_in = dict(entry_env)

    worklist = [prog.entry]
    visited = set()
    guard = 0
    while worklist and guard < 20000:
        guard += 1
        sid = worklist.pop(0)
        if sid not in prog.states:
            continue
        st = prog.states[sid]
        visited.add(sid)
        env_out = interp.run(st, st.env_in)
        for succ, cond_env in _successors(prog, st, env_out, interp):
            if succ not in prog.states:
                continue
            if merge_env(prog.states[succ].env_in, cond_env) or succ not in visited:
                worklist.append(succ)
    for sid in visited:
        prog.states[sid].reachable = True
    for sid in set(prog.states) - visited:
        prog.states[sid].reachable = False
    return {sid: prog.states[sid].env_in for sid in visited}


def _successors(prog: Program, st: State, env_out: dict, interp: Interp):
    t = st.term
    if t[0] == "goto":
        return [(t[1], env_out)]
    if t[0] == "branch":
        _, full = interp.make_eval(env_out)
        c = truthy(full(t[1]))
        if c is True:
            return [(t[2], env_out)]
        if c is False:
            return [(t[3], env_out)]
        return [(t[2], env_out), (t[3], env_out)]
    return []


def resolve_branches(prog: Program) -> int:
    """Collapse branches whose condition SCCP proved constant."""
    aliases = collect_aliases(prog)
    interp = Interp(prog, aliases)
    folded = 0
    for st in prog.states.values():
        if not st.reachable or st.term[0] != "branch":
            continue
        env_out = interp.run(st, st.env_in)
        _, full = interp.make_eval(env_out)
        c = truthy(full(st.term[1]))
        if c is True:
            st.term = ("goto", st.term[2])
            folded += 1
        elif c is False:
            st.term = ("goto", st.term[3])
            folded += 1
    return folded
