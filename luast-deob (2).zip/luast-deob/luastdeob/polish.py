"""Readability passes applied after control flow has been recovered."""
from __future__ import annotations

from . import ast_nodes as A
from .printer import to_source

CONTROL = (A.If, A.While, A.Repeat, A.NumericFor, A.GenericFor, A.Do,
           A.FunctionStat, A.Return, A.Break, A.Continue)


# ------------------------------------------------------------ method calls

def restore_method_calls(node):
    """`obj.m(obj, ...)`  ->  `obj:m(...)`"""
    def fix(e):
        if isinstance(e, A.Call) and isinstance(e.func, A.Index) and e.args and \
                isinstance(e.func.key, A.String):
            try:
                if to_source(e.func.obj) == to_source(e.args[0]):
                    name = e.func.key.value.decode("latin-1")
                    if name.isidentifier():
                        return A.MethodCall(e.func.obj, name, e.args[1:], line=e.line)
            except Exception:
                pass
        return e
    return _map_exprs(node, fix)


def _map_exprs(node, fn):
    if isinstance(node, list):
        return [_map_exprs(x, fn) for x in node]
    if isinstance(node, tuple):
        return tuple(_map_exprs(x, fn) for x in node)
    if not isinstance(node, A.Node):
        return node
    for f in getattr(node, "__dataclass_fields__", {}):
        setattr(node, f, _map_exprs(getattr(node, f), fn))
    return fn(node)


# ------------------------------------------------------- copy propagation

def _count_reads(nodes, name) -> int:
    n = 0
    for x in A.walk(nodes):
        if isinstance(x, A.Assign):
            for t in x.targets:
                if isinstance(t, A.Name) and t.name == name:
                    n -= 1
        if isinstance(x, A.Name) and x.name == name:
            n += 1
    return max(n, 0)


def _writes(nodes, name) -> int:
    n = 0
    for x in A.walk(nodes):
        if isinstance(x, A.Assign):
            n += sum(1 for t in x.targets if isinstance(t, A.Name) and t.name == name)
        elif isinstance(x, A.LocalAssign):
            n += sum(1 for t in x.names if t == name)
        elif isinstance(x, A.CompoundAssign) and isinstance(x.target, A.Name) \
                and x.target.name == name:
            n += 1
        elif isinstance(x, A.NumericFor) and x.var == name:
            n += 1
        elif isinstance(x, A.GenericFor) and name in x.names:
            n += 1
    return n


def _subst(node, name, repl):
    def fix(e):
        if isinstance(e, A.Name) and e.name == name:
            return repl
        return e
    return _map_exprs(node, fix)


def copy_propagate(block: A.Block, root: A.Block) -> int:
    """Forward simple `x = y` / `x = <literal>` copies inside straight-line runs."""
    changed = 0
    for node in A.walk(block):
        if not isinstance(node, A.Block):
            continue
        i = 0
        while i < len(node.stmts):
            s = node.stmts[i]
            target = value = None
            if isinstance(s, A.Assign) and len(s.targets) == len(s.values) == 1 \
                    and isinstance(s.targets[0], A.Name):
                target, value = s.targets[0].name, s.values[0]
            elif isinstance(s, A.LocalAssign) and len(s.names) == len(s.values) == 1:
                target, value = s.names[0], s.values[0]
            if target is None or not isinstance(
                    value, (A.Name, A.Number, A.String, A.Nil, A.TrueLit, A.FalseLit)):
                i += 1
                continue
            if _writes(root, target) != 1:
                i += 1
                continue
            # only substitute into the straight-line tail of this block
            tail, stop = [], len(node.stmts)
            for j in range(i + 1, len(node.stmts)):
                if isinstance(node.stmts[j], CONTROL):
                    stop = j
                    break
                tail.append(node.stmts[j])
            else:
                stop = len(node.stmts)
            rest = node.stmts[stop:]
            if _count_reads(rest, target) or _count_reads(rest, target):
                pass
            if _count_reads(node.stmts[stop:], target):
                i += 1
                continue
            if isinstance(value, A.Name) and _writes(tail, value.name):
                i += 1
                continue
            reads = _count_reads(tail, target)
            if reads == 0:
                i += 1
                continue
            for j in range(i + 1, stop):
                node.stmts[j] = _subst(node.stmts[j], target, value)
            del node.stmts[i]
            changed += 1
    return changed


# ---------------------------------------------------------- numeric for loops

def recover_for_loops(block: A.Block) -> int:
    n = 0
    for node in A.walk(block):
        if not isinstance(node, A.Block):
            continue
        i = 0
        while i < len(node.stmts) - 1:
            init, loop = node.stmts[i], node.stmts[i + 1]
            got = _try_for(init, loop, node.stmts[i + 2:])
            if got is not None:
                node.stmts[i:i + 2] = [got]
                n += 1
            else:
                i += 1
    return n


def _try_for(init, loop, after):
    if not isinstance(loop, A.While) or not isinstance(loop.cond, A.BinOp):
        return None
    if loop.cond.op not in ("<=", ">="):
        return None
    if not isinstance(loop.cond.left, A.Name):
        return None
    var = loop.cond.left.name
    if isinstance(init, A.Assign) and len(init.targets) == len(init.values) == 1 \
            and isinstance(init.targets[0], A.Name) and init.targets[0].name == var:
        start = init.values[0]
    elif isinstance(init, A.LocalAssign) and init.names == [var] and len(init.values) == 1:
        start = init.values[0]
    else:
        return None
    body = list(loop.body.stmts)
    if not body:
        return None
    last = body[-1]
    step = None
    if isinstance(last, A.CompoundAssign) and isinstance(last.target, A.Name) \
            and last.target.name == var and last.op in ("+", "-"):
        step = last.value
        if last.op == "-":
            step = A.UnOp("-", step)
    elif isinstance(last, A.Assign) and len(last.targets) == 1 and \
            isinstance(last.targets[0], A.Name) and last.targets[0].name == var and \
            isinstance(last.values[0], A.BinOp) and last.values[0].op in ("+", "-") and \
            isinstance(last.values[0].left, A.Name) and last.values[0].left.name == var:
        step = last.values[0].right
        if last.values[0].op == "-":
            step = A.UnOp("-", step)
    if step is None:
        return None
    inner = body[:-1]
    if _writes(inner, var):
        return None
    if _count_reads(after, var):
        return None
    if any(isinstance(x, (A.Break, A.Continue)) for x in A.walk(inner)):
        return None
    step_is_one = isinstance(step, A.Number) and step.value == 1
    if loop.cond.op == ">=" and step_is_one:
        return None
    return A.NumericFor(var, start, loop.cond.right, None if step_is_one else step,
                        A.Block(inner), line=loop.line)


# ------------------------------------------------------------------ renaming

def rename_variables(block: A.Block, reserved: set | None = None) -> dict:
    """Give the surviving obfuscated locals short, readable names."""
    reserved = reserved or set()
    loop_vars, others, order = [], [], []
    for n in A.walk(block):
        if isinstance(n, A.NumericFor) and n.var not in loop_vars:
            loop_vars.append(n.var)
        elif isinstance(n, A.GenericFor):
            for v in n.names:
                if v not in loop_vars:
                    loop_vars.append(v)
    for n in A.walk(block):
        if isinstance(n, A.LocalAssign):
            order.extend(n.names)
        elif isinstance(n, A.Assign):
            order.extend(t.name for t in n.targets if isinstance(t, A.Name))
        elif isinstance(n, A.CompoundAssign) and isinstance(n.target, A.Name):
            order.append(n.target.name)
    for v in order:
        if v not in loop_vars and v not in others:
            others.append(v)

    mapping = {}
    pool_i = iter("ijkmnpq")
    for v in loop_vars:
        if not _looks_obfuscated(v):
            continue
        try:
            mapping[v] = next(pool_i)
        except StopIteration:
            mapping[v] = f"i{len(mapping)}"
    k = 1
    for v in others:
        if not _looks_obfuscated(v) or v in mapping:
            continue
        mapping[v] = f"v{k}"
        k += 1
    mapping = {a: b for a, b in mapping.items() if b not in reserved}

    def fix(e):
        if isinstance(e, A.Name) and e.name in mapping:
            return A.Name(mapping[e.name], line=e.line)
        if isinstance(e, A.NumericFor) and e.var in mapping:
            e.var = mapping[e.var]
        if isinstance(e, A.GenericFor):
            e.names = [mapping.get(x, x) for x in e.names]
        if isinstance(e, A.LocalAssign):
            e.names = [mapping.get(x, x) for x in e.names]
        return e
    _map_exprs(block, fix)
    return mapping


def _looks_obfuscated(name: str) -> bool:
    return bool(name) and len(name) <= 3 and not name.isupper()


# ------------------------------------------------------------- declarations

def localize(block: A.Block, known_locals: set) -> None:
    """Re-introduce `local` for VM-hoisted variables so nothing leaks global."""
    assigned_top: list[str] = []
    for n in A.walk(block):
        if isinstance(n, A.Assign):
            for t in n.targets:
                if isinstance(t, A.Name) and t.name in known_locals and \
                        t.name not in assigned_top:
                    assigned_top.append(t.name)
        elif isinstance(n, A.CompoundAssign) and isinstance(n.target, A.Name) \
                and n.target.name in known_locals and n.target.name not in assigned_top:
            assigned_top.append(n.target.name)
    declared = set()
    for n in A.walk(block):
        if isinstance(n, A.LocalAssign):
            declared.update(n.names)
        elif isinstance(n, A.NumericFor):
            declared.add(n.var)
        elif isinstance(n, A.GenericFor):
            declared.update(n.names)
    need = [v for v in assigned_top if v not in declared]
    if not need:
        return
    # promote the first top-level assignment of each to a `local`
    still = list(need)
    for idx, s in enumerate(block.stmts):
        if not still:
            break
        if isinstance(s, A.Assign) and len(s.targets) == 1 and \
                isinstance(s.targets[0], A.Name) and s.targets[0].name in still:
            name = s.targets[0].name
            block.stmts[idx] = A.LocalAssign([name], list(s.values), line=s.line)
            still.remove(name)
    if still:
        block.stmts.insert(0, A.LocalAssign(list(still), [], line=0))


def polish(block: A.Block, known_locals: set) -> A.Block:
    restore_method_calls(block)
    for _ in range(6):
        if not copy_propagate(block, block):
            break
    recover_for_loops(block)
    for _ in range(3):
        if not copy_propagate(block, block):
            break
    localize(block, known_locals)
    rename_variables(block)
    return block
