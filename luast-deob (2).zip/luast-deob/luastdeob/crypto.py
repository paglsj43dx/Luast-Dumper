"""String decryption + payload decoding for luast.

luast encrypts each string constant as:

    K0 = mix(seed)                       -- seed = (state + tamper_accumulator) % m
    for each 4-byte block:  K = K*MUL + ADD (mod 2^32);  plain = cipher - K
    tail bytes use one more K, consumed byte-by-byte

`seed` depends on an anti-tamper accumulator that only has its real value
inside a pristine Roblox VM, so we never try to reproduce it.  Instead we
recover the keystream directly: because the key schedule is an LCG mod 2^32,
byte-plane *p* of every key depends only on the low 8*(p+1) bits of K0, so the
key can be lifted one byte-plane at a time against a printability constraint.
That is environment independent and runs in milliseconds.
"""
from __future__ import annotations

import base64
import json
import math
import re
import struct
from dataclasses import dataclass, field

MASK = 0xFFFFFFFF
M32 = 1 << 32

# ---------------------------------------------------------------- mix function


@dataclass
class MixSpec:
    """The `W = ...` pipeline luast inlines as its key-derivation function."""
    ops: list[tuple[str, int]] = field(default_factory=list)

    def __call__(self, w: int) -> int:
        w &= MASK
        for kind, arg in self.ops:
            if kind == "add":
                w = (w + arg) & MASK
            elif kind == "xorshr":
                w ^= w >> arg
            elif kind == "xorshl":
                w = (w ^ (w << arg)) & MASK
            elif kind == "rotl":
                arg %= 32
                w = ((w << arg) | (w >> (32 - arg))) & MASK
            else:
                raise ValueError(f"unknown mix op {kind}")
        return w & MASK

    def invert(self, w: int) -> int:
        w &= MASK
        for kind, arg in reversed(self.ops):
            if kind == "add":
                w = (w - arg) & MASK
            elif kind == "xorshr":
                w = _inv_xor_shr(w, arg)
            elif kind == "xorshl":
                w = _inv_xor_shl(w, arg)
            elif kind == "rotl":
                arg %= 32
                w = ((w >> arg) | (w << (32 - arg))) & MASK
        return w & MASK


def _inv_xor_shr(y: int, k: int) -> int:
    x = y
    for _ in range(32 // max(k, 1) + 1):
        x = y ^ (x >> k)
    return x & MASK


def _inv_xor_shl(y: int, k: int) -> int:
    x = y
    for _ in range(32 // max(k, 1) + 1):
        x = (y ^ (x << k)) & MASK
    return x & MASK


# The v1.0.1 pipeline, used as a fallback when it cannot be read off the AST.
DEFAULT_MIX = MixSpec([
    ("add", 2654435769), ("xorshr", 16), ("xorshl", 5), ("rotl", 11),
    ("add", 2246822507), ("xorshr", 13), ("xorshl", 9), ("rotl", 19),
    ("add", 3266489909), ("xorshr", 15), ("xorshl", 7), ("rotl", 23),
    ("add", 668265263), ("xorshr", 17), ("xorshl", 11), ("rotl", 13),
    ("add", 374761393), ("xorshr", 11), ("xorshl", 13), ("rotl", 7),
    ("add", 4283543511), ("xorshr", 14), ("xorshl", 6), ("rotl", 17),
])


def modinv(a: int, m: int = M32) -> int:
    return pow(a, -1, m)


# ---------------------------------------------------------------- key recovery

_PRINTABLE = set(range(0x20, 0x7F)) | {9, 10, 13}
_STRICT = set(b"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
              b" _.:/?=&%-,'\"()[]{}!#@+*<>|~^$;\\\n\t")
_ALLOWED = _PRINTABLE

# A plane-2 survivor count above this makes the final plane too costly; we then
# retry with a tighter alphabet rather than grinding.
WORK_CAP = 300_000


def _blocks(ct: bytes, plen: int) -> list[int]:
    n = plen - (plen % 4)
    return [struct.unpack_from("<I", ct, i)[0] for i in range(0, n, 4)]


def _tail(ct: bytes, plen: int) -> bytes:
    return ct[plen - (plen % 4):plen]


class Underdetermined(Exception):
    """Too many keys survive the printability filter to enumerate."""


# ---- numpy fast path --------------------------------------------------------

def _np():
    try:
        import numpy
        return numpy
    except ImportError:
        return None


def _lift_np(np, ct, plen, mul, add, allowed, cap=WORK_CAP, chunk=1 << 15):
    blocks = _blocks(ct, plen)
    tail = _tail(ct, plen)
    amask = np.zeros(256, dtype=bool)
    amask[list(allowed)] = True
    u32 = np.uint32
    cands = np.zeros(1, dtype=np.uint32)
    with np.errstate(over="ignore"):
        for plane in range(4):
            sh = u32(8 * plane)
            offs = np.arange(256, dtype=np.uint32) * u32(1 << (8 * plane))
            pieces = []
            for i in range(0, cands.size, chunk):
                exp = (cands[i:i + chunk][:, None] + offs[None, :]).ravel()
                keep = np.ones(exp.size, dtype=bool)
                k = exp.copy()
                for b in blocks:
                    byte = ((u32(b) - k) >> sh) & u32(0xFF)
                    keep &= amask[byte]
                    k = k * u32(mul) + u32(add)
                if plane < len(tail):
                    byte = (u32(tail[plane]) - ((k >> sh) & u32(0xFF))) & u32(0xFF)
                    keep &= amask[byte]
                pieces.append(exp[keep])
            cands = np.concatenate(pieces) if pieces else np.empty(0, np.uint32)
            if cands.size == 0:
                return cands
            if plane < 3 and cands.size > cap:
                raise Underdetermined(f"{cands.size} keys still alive at plane {plane}")
    return cands


def _plaintexts_np(np, keys, ct, plen, mul, add):
    blocks = _blocks(ct, plen)
    tail = _tail(ct, plen)
    u32 = np.uint32
    out = np.zeros((keys.size, plen), dtype=np.uint8)
    with np.errstate(over="ignore"):
        k = keys.copy()
        for i, b in enumerate(blocks):
            v = u32(b) - k
            for j in range(4):
                out[:, 4 * i + j] = (v >> u32(8 * j)) & u32(0xFF)
            k = k * u32(mul) + u32(add)
        for j in range(len(tail)):
            out[:, 4 * len(blocks) + j] = \
                (u32(tail[j]) - ((k >> u32(8 * j)) & u32(0xFF))) & u32(0xFF)
    return out


def recover_keys(ct: bytes, plen: int, mul: int, add: int,
                 allowed: set[int] | None = None, limit: int = 2_000_000) -> list[int]:
    """Every K1 whose keystream turns `ct` into an all-printable plaintext."""
    allowed = allowed or _ALLOWED
    if plen < 4:
        return []
    np = _np()
    if np is not None:
        keys = _lift_np(np, ct, plen, mul, add, allowed)
        if keys.size > limit:
            # never silently truncate: a caller would lose the real key
            raise Underdetermined(f"{keys.size} keys fit (limit {limit})")
        return keys.tolist()
    return _recover_keys_py(ct, plen, mul, add, allowed, limit)


def _recover_keys_py(ct, plen, mul, add, allowed, limit):
    blocks = _blocks(ct, plen)
    tail = _tail(ct, plen)
    if not blocks:
        return []
    cands = [0]
    for plane in range(4):
        lo = 1 << (8 * plane)
        nxt = []
        for base in cands:
            for hi in range(256):
                k1 = base + hi * lo
                k = k1
                ok = True
                for b in blocks:
                    if ((b - k) >> (8 * plane)) & 0xFF not in allowed:
                        ok = False
                        break
                    k = (k * mul + add) & MASK
                if ok and plane < len(tail):
                    if ((tail[plane] - ((k >> (8 * plane)) & 0xFF)) & 0xFF) not in allowed:
                        ok = False
                if ok:
                    nxt.append(k1)
        cands = nxt
        if not cands:
            return []
        if plane < 3 and len(cands) > WORK_CAP:
            raise Underdetermined(f"{len(cands)} keys alive at plane {plane}")
    return cands[:limit]


def decrypt_with_key(ct: bytes, plen: int, k1: int, mul: int, add: int) -> bytes:
    """Replay luast's decryptor given the first block key."""
    if plen <= 0:
        return b""
    if 1 <= plen <= 3:
        return bytes(((ct[i] - ((k1 >> (8 * i)) & 0xFF)) & 0xFF) for i in range(plen))
    buf = bytearray(ct[:plen] + b"\x00" * (-plen % 4))
    k = k1
    n = 0
    while n <= plen - 4:
        v = struct.unpack_from("<I", buf, n)[0]
        struct.pack_into("<I", buf, n, (v - k) & MASK)
        k = (k * mul + add) & MASK
        n += 4
    if n < plen:
        j = 0
        while n < plen:
            buf[n] = (buf[n] - ((k >> (8 * j)) & 0xFF)) & 0xFF
            n += 1
            j += 1
    return bytes(buf[:plen])


def seed_from_key(k1: int, mul: int, add: int, mix: MixSpec) -> int:
    """Invert  K1 = mix(seed)*MUL + ADD  to get the tamper-derived seed."""
    return mix.invert(((k1 - add) * modinv(mul)) & MASK)


# ---------------------------------------------------------------- scoring

_CORPUS = (
    "the quick brown fox jumps over the lazy dog and then it runs away again "
    "this is a message from the server to the client please wait a moment "
    "hello world how are you today i am fine thank you very much for asking "
    "error failed to load resource not found invalid argument expected string "
    "local function return end then else for while do if not and or true false "
    "game:GetService('Players') game:GetService('ReplicatedStorage') workspace "
    "print warn error pcall ipairs pairs table.insert string.format tostring "
    "https://example.com/api/v1/endpoint?key=value&id=12345 discord webhook url "
    "Instance.new('Part') Vector3.new(0,0,0) CFrame.new() task.wait() spawn "
    "player character humanoid root part position velocity health name userid "
    "Successfully loaded configuration settings from the data store service "
    "you do not have permission to run this command please contact an admin "
    "script parent name value text label button frame screen gui visible size "
    "Players Humanoid HumanoidRootPart Workspace Character LocalPlayer Camera "
    "RunService UserInputService TweenService Lighting StarterGui Backpack "
    "MouseButton1Click Touched Changed Heartbeat RenderStepped PlayerAdded "
    "Position Orientation Transparency Anchored CanCollide Material BrickColor "
)


def _build_bigrams():
    counts: dict[tuple[int, int], int] = {}
    totals: dict[int, int] = {}
    data = _CORPUS.encode()
    for a, b in zip(data, data[1:]):
        counts[(a, b)] = counts.get((a, b), 0) + 1
        totals[a] = totals.get(a, 0) + 1
    return counts, totals


_BIGRAMS, _TOTALS = _build_bigrams()
_V = 96.0


def score_plaintext(pt: bytes) -> float:
    """Higher = more likely to be a real string rather than keystream garbage."""
    if not pt:
        return -1e9
    s = 0.0
    for a, b in zip(pt, pt[1:]):
        c = _BIGRAMS.get((a, b), 0)
        t = _TOTALS.get(a, 0)
        s += math.log((c + 0.12) / (t + 0.12 * _V))
    s /= max(len(pt) - 1, 1)

    txt = pt.decode("latin-1")
    lower = sum(1 for c in txt if c.islower())
    upper = sum(1 for c in txt if c.isupper())
    digit = sum(1 for c in txt if c.isdigit())
    space = txt.count(" ")
    other = len(txt) - lower - upper - digit - space
    n = len(txt)
    s += 1.6 * (lower / n)
    s += 0.5 * (space / n)
    s -= 2.2 * (other / n)
    s -= 0.7 * (upper / n)
    if re.fullmatch(r"[A-Za-z0-9_.:/?=&%#@!,'\"() \[\]{}+-]*", txt):
        s += 0.35
    if re.search(r"[A-Za-z]{4,}", txt):
        s += 0.45
    # runs of >3 consecutive symbols/controls are a strong garbage signal
    if re.search(r"[^A-Za-z0-9 _]{4,}", txt):
        s -= 0.8
    return s


def _bigram_table(np):
    tab = np.full((256, 256), -12.0, dtype=np.float32)
    for (a, b), c in _BIGRAMS.items():
        tab[a, b] = math.log((c + 0.12) / (_TOTALS[a] + 0.12 * _V))
    for a, t in _TOTALS.items():
        row = tab[a]
        row[row == -12.0] = math.log(0.12 / (t + 0.12 * _V))
    return tab


def shortlist(ct: bytes, plen: int, mul: int, add: int, top: int = 48):
    """Best-scoring decryptions, with the total number of keys that fit.

    Returns (candidates, total, alphabet) where `candidates` is a list of
    (score, key, plaintext) sorted best-first.
    """
    np = _np()
    last_err = None
    for alphabet, name in ((_PRINTABLE, "printable"), (_STRICT, "strict")):
        try:
            if np is None:
                keys = _recover_keys_py(ct, plen, mul, add, alphabet, 200_000)
                if not keys:
                    continue
                scored = [(score_plaintext(decrypt_with_key(ct, plen, k, mul, add)), k,
                           decrypt_with_key(ct, plen, k, mul, add)) for k in keys]
                scored.sort(key=lambda x: -x[0])
                return scored[:top], len(keys), name

            keys = _lift_np(np, ct, plen, mul, add, alphabet)
            if keys.size == 0:
                continue
            total = int(keys.size)
            if total > 4096:               # coarse vectorised pre-ranking
                tab = _bigram_table(np)
                best_idx, best_val = None, None
                step = 1 << 20
                for i in range(0, total, step):
                    chunk = keys[i:i + step]
                    pts = _plaintexts_np(np, chunk, ct, plen, mul, add)
                    sc = tab[pts[:, :-1], pts[:, 1:]].sum(axis=1)
                    n = min(top * 16, sc.size)
                    idx = np.argpartition(-sc, n - 1)[:n]
                    if best_idx is None:
                        best_idx, best_val = chunk[idx], sc[idx]
                    else:
                        best_idx = np.concatenate([best_idx, chunk[idx]])
                        best_val = np.concatenate([best_val, sc[idx]])
                keys = best_idx
            scored = []
            for k in keys.tolist():
                pt = decrypt_with_key(ct, plen, int(k), mul, add)
                scored.append((score_plaintext(pt), int(k), pt))
            scored.sort(key=lambda x: -x[0])
            return scored[:top], total, name
        except Underdetermined as exc:
            last_err = exc
            continue
    if last_err:
        raise last_err
    return [], 0, "none"


@dataclass
class Decryption:
    ciphertext: bytes
    plaintext: bytes
    key: int
    seed: int | None
    candidates: int
    score: float
    ambiguous: bool
    alphabet: str = "printable"


def decrypt_string(ct: bytes, pad: int, mul: int, add: int,
                   mix: MixSpec = DEFAULT_MIX,
                   margin: float = 0.55) -> Decryption | None:
    plen = len(ct) - pad
    if plen < 4:
        return None
    try:
        scored, total, alphabet = shortlist(ct, plen, mul, add)
    except Underdetermined:
        return None
    if not scored:
        return None
    best = scored[0]
    # Short ciphertexts leave so many keys fitting the printability filter that
    # the ranking stops being trustworthy; say so instead of pretending.
    ambiguous = (total > 100_000) or \
                (len(scored) > 1 and (best[0] - scored[1][0]) < margin)
    try:
        seed = seed_from_key(best[1], mul, add, mix)
    except Exception:
        seed = None
    return Decryption(ct, best[2], best[1], seed, total, best[0], ambiguous, alphabet)


def rank_candidates(ct: bytes, pad: int, mul: int, add: int, top: int = 10):
    plen = len(ct) - pad
    try:
        scored, _, _ = shortlist(ct, plen, mul, add, top=max(top, 12))
    except Underdetermined:
        return []
    return scored[:top]


# ---------------------------------------------------------------- payload blobs

def decode_roblox_json_value(text: str):
    """Rehydrate Roblox's JSONEncode representation of a buffer, if that's what
    this string is.  Returns (kind, value)."""
    try:
        obj = json.loads(text)
    except Exception:
        return ("raw", text)
    if isinstance(obj, dict) and obj.get("t") == "buffer" and "zbase64" in obj:
        raw = base64.b64decode(obj["zbase64"])
        return ("buffer", zstd_decompress(raw))
    if isinstance(obj, dict) and obj.get("t") == "buffer" and "base64" in obj:
        return ("buffer", base64.b64decode(obj["base64"]))
    return ("json", obj)


def zstd_decompress(raw: bytes) -> bytes:
    try:
        import zstandard
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "zstd payload found but the `zstandard` package is missing; "
            "install it with `pip install zstandard`") from exc
    return zstandard.ZstdDecompressor().decompress(raw)
