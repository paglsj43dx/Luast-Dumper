"""Constant folding / partial evaluation over the parsed AST."""
from __future__ import annotations

import math

from . import ast_nodes as A
from .values import (NIL, UNDEF, UNKNOWN, Builtin, ConstTable, is_number,
                     is_string, lua_tostring, norm_num, truthy)

MASK = 0xFFFFFFFF

# Globals we are happy to name symbolically.
KNOWN_GLOBALS = {
    "print", "warn", "error", "assert", "pcall", "xpcall", "select", "type",
    "typeof", "tostring", "tonumber", "rawget", "rawset", "rawequal", "rawlen",
    "ipairs", "pairs", "next", "unpack", "require", "getmetatable",
    "setmetatable", "newproxy", "collectgarbage", "loadstring",
    "math", "string", "table", "bit32", "buffer", "coroutine", "os", "debug",
    "utf8", "task", "game", "workspace", "script", "shared", "Enum",
    "Instance", "Vector2", "Vector3", "Vector2int16", "Vector3int16", "CFrame",
    "Color3", "UDim", "UDim2", "Ray", "Region3", "BrickColor", "Font",
    "TweenInfo", "NumberRange", "NumberSequence", "ColorSequence", "Random",
    "DateTime", "PhysicalProperties", "Rect", "Axes", "Faces", "_G", "_VERSION",
    "getfenv", "setfenv", "gcinfo", "delay", "spawn", "wait", "tick", "time",
}


def _bit(v) -> int:
    return int(v) & MASK


class ConstEvaluator:
    """Folds expressions to concrete values where possible.

    `lookup` resolves a variable name to a value (or UNKNOWN);
    `table_get` resolves ConstTable[index].
    """

    def __init__(self, lookup=None, table_get=None):
        self.lookup = lookup or (lambda n: UNKNOWN)
        self.table_get = table_get or (lambda t, k: UNKNOWN)

    # ------------------------------------------------------------ entry point
    def eval(self, e):
        m = getattr(self, "_e_" + type(e).__name__, None)
        if m is None:
            return UNKNOWN
        try:
            return m(e)
        except (ZeroDivisionError, OverflowError, ValueError, TypeError):
            return UNKNOWN

    # ------------------------------------------------------------ literals
    def _e_Nil(self, e):
        return NIL

    def _e_TrueLit(self, e):
        return True

    def _e_FalseLit(self, e):
        return False

    def _e_Number(self, e):
        return norm_num(e.value)

    def _e_String(self, e):
        return e.value

    def _e_Paren(self, e):
        return self.eval(e.inner)

    def _e_Name(self, e):
        v = self.lookup(e.name)
        if v is UNKNOWN and e.name in KNOWN_GLOBALS:
            return Builtin(e.name)
        return v

    # ------------------------------------------------------------ compound
    def _e_Index(self, e):
        obj = self.eval(e.obj)
        key = self.eval(e.key)
        if obj is UNKNOWN or obj is UNDEF or key is UNKNOWN or key is UNDEF:
            return UNKNOWN
        if isinstance(obj, ConstTable):
            return self.table_get(obj, key)
        if isinstance(obj, Builtin) and is_string(key):
            return Builtin(f"{obj.name}.{key.decode('latin-1')}")
        return UNKNOWN

    def _e_Call(self, e):
        return UNKNOWN

    def _e_MethodCall(self, e):
        return UNKNOWN

    def _e_Function(self, e):
        return UNKNOWN

    def _e_Table(self, e):
        return UNKNOWN

    def _e_VarArg(self, e):
        return UNKNOWN

    def _e_IfExpr(self, e):
        for cond, val in e.branches:
            t = truthy(self.eval(cond))
            if t is UNKNOWN:
                return UNKNOWN
            if t:
                return self.eval(val)
        return self.eval(e.orelse)

    def _e_UnOp(self, e):
        v = self.eval(e.operand)
        if e.op == "not":
            t = truthy(v)
            return UNKNOWN if t is UNKNOWN else (not t)
        if v is UNKNOWN or v is UNDEF:
            return UNKNOWN
        if e.op == "-":
            return norm_num(-v) if is_number(v) else UNKNOWN
        if e.op == "#":
            if is_string(v):
                return len(v)
            return UNKNOWN
        return UNKNOWN

    def _e_BinOp(self, e):
        op = e.op
        if op in ("and", "or"):
            lv = self.eval(e.left)
            t = truthy(lv)
            if t is UNKNOWN:
                return UNKNOWN
            if op == "and":
                return self.eval(e.right) if t else lv
            return lv if t else self.eval(e.right)

        # x == x  /  x ~= x : luast's favourite opaque predicate.
        if op in ("==", "~=") and _same_scalar(e.left, e.right):
            return (op == "==")

        # `v * v < 0` / `v * v >= 0` junk guards around unreachable filler code.
        if op in ("<", ">=", ">", "<="):
            sq, other, flip = (e.left, e.right, False) if _is_square(e.left) \
                else (e.right, e.left, True)
            if _is_square(sq):
                ov = self.eval(other)
                if is_number(ov) and ov == 0:
                    lt = (op in ("<", "<=")) ^ flip
                    if op in ("<", ">"):
                        return False if lt else True
                    return True if not lt else False

        lv = self.eval(e.left)
        rv = self.eval(e.right)
        # NaN (luast writes it as `0/0`) is unequal to absolutely everything,
        # which is how its unreachable filler loops are guarded.
        if op in ("==", "~="):
            for side in (lv, rv):
                if is_number(side) and side != side:
                    return op == "~="
        if lv is UNKNOWN or rv is UNKNOWN or lv is UNDEF or rv is UNDEF:
            return UNKNOWN

        if op == "==":
            return _lua_eq(lv, rv)
        if op == "~=":
            r = _lua_eq(lv, rv)
            return UNKNOWN if r is UNKNOWN else (not r)
        if op == "..":
            if (is_string(lv) or is_number(lv)) and (is_string(rv) or is_number(rv)):
                return (lua_tostring(lv) + lua_tostring(rv)).encode("latin-1")
            return UNKNOWN

        if not (is_number(lv) and is_number(rv)):
            return UNKNOWN
        if op == "+":
            return norm_num(lv + rv)
        if op == "-":
            return norm_num(lv - rv)
        if op == "*":
            return norm_num(lv * rv)
        if op == "/":
            if rv == 0:
                if lv == 0:
                    return math.nan
                return math.inf if lv > 0 else -math.inf
            return norm_num(lv / rv)
        if op == "//":
            if rv == 0:
                return UNKNOWN
            return norm_num(math.floor(lv / rv))
        if op == "%":
            if rv == 0:
                return math.nan
            return norm_num(lv - math.floor(lv / rv) * rv)
        if op == "^":
            return norm_num(float(lv) ** float(rv))
        if op == "<":
            return lv < rv
        if op == "<=":
            return lv <= rv
        if op == ">":
            return lv > rv
        if op == ">=":
            return lv >= rv
        return UNKNOWN


def _same_scalar(a, b) -> bool:
    """True when both sides are syntactically the same simple variable."""
    return isinstance(a, A.Name) and isinstance(b, A.Name) and a.name == b.name


def _is_square(e) -> bool:
    e = e.inner if isinstance(e, A.Paren) else e
    return isinstance(e, A.BinOp) and e.op == "*" and _same_scalar(e.left, e.right)


def _lua_eq(a, b):
    if is_number(a) and is_number(b):
        if a != a or b != b:          # NaN compares false against everything
            return False
        return a == b
    if is_string(a) and is_string(b):
        return a == b
    if isinstance(a, bool) or isinstance(b, bool):
        return a is b
    if a is NIL or b is NIL:
        return a is b
    if isinstance(a, Builtin) and isinstance(b, Builtin):
        return a.name == b.name
    if type(a) is not type(b):
        return False
    return UNKNOWN


# --------------------------------------------------------------- bit32 helpers

BIT32_OPS = {
    "bit32.band":   lambda *a: _fold(a, lambda x, y: x & y, MASK),
    "bit32.bor":    lambda *a: _fold(a, lambda x, y: x | y, 0),
    "bit32.bxor":   lambda *a: _fold(a, lambda x, y: x ^ y, 0),
    "bit32.bnot":   lambda x: (~_bit(x)) & MASK,
    "bit32.lshift": lambda x, n: (_bit(x) << (int(n) & 31)) & MASK if 0 <= int(n) < 32 else 0,
    "bit32.rshift": lambda x, n: (_bit(x) >> (int(n) & 31)) if 0 <= int(n) < 32 else 0,
    "bit32.arshift": lambda x, n: (_bit(x) >> (int(n) & 31)) if 0 <= int(n) < 32 else 0,
    "bit32.lrotate": lambda x, n: ((_bit(x) << (int(n) % 32)) | (_bit(x) >> (32 - (int(n) % 32) or 32))) & MASK,
    "bit32.rrotate": lambda x, n: ((_bit(x) >> (int(n) % 32)) | (_bit(x) << (32 - (int(n) % 32) or 32))) & MASK,
    "math.floor":   lambda x: int(math.floor(x)),
    "math.ceil":    lambda x: int(math.ceil(x)),
    "math.abs":     lambda x: abs(x),
    "math.sign":    lambda x: (0 if x == 0 else (1 if x > 0 else -1)),
    "math.max":     lambda *a: max(a),
    "math.min":     lambda *a: min(a),
}


def _fold(args, fn, init):
    acc = init
    for a in args:
        acc = fn(acc, _bit(a))
    return acc & MASK
