"""Turn luast's flattened state machine back into a control-flow graph.

luast does *not* compile to bytecode: it keeps the original Luau statements and
scatters them across numbered states of a `while true do ... end` dispatcher,
reached through a binary search tree over a state variable that is re-mapped
every iteration (`state = K - state`).  So recovering the program is a matter of
  1. reading the constant pool (and replaying the shuffle applied to it),
  2. enumerating the states by evaluating the search tree for each state id,
  3. constant-propagating so the opaque predicates collapse,
  4. keeping only the statements that belong to the user's program.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from . import ast_nodes as A
from .consteval import BIT32_OPS, ConstEvaluator
from .values import (NIL, UNDEF, UNKNOWN, Builtin, ConstTable, is_number,
                     is_string, norm_num, truthy)


# ------------------------------------------------------------------ containers

@dataclass
class State:
    sid: int                      # logical state id (the value assigned to the state var)
    raw: int                      # id after the dispatcher's re-mapping
    stmts: list = field(default_factory=list)
    term: tuple = ("exit",)       # ('goto', s) | ('branch', cond, s_true, s_false) | ('exit',)
    reachable: bool = False
    env_in: dict = field(default_factory=dict)


@dataclass
class Program:
    consts: dict = field(default_factory=dict)          # 1-based index -> value
    states: dict = field(default_factory=dict)          # sid -> State
    entry: int = 0
    state_var: str = ""
    table_var: str = ""
    prelude: dict = field(default_factory=dict)         # alias -> Builtin
    vm_vars: set = field(default_factory=set)
    warnings: list = field(default_factory=list)
    mix_ops: list = field(default_factory=list)
    lcg: tuple = (1597, 51749)


# ------------------------------------------------------------------ extraction

def _num(e):
    if isinstance(e, A.Number):
        return norm_num(e.value)
    if isinstance(e, A.UnOp) and e.op == "-" and isinstance(e.operand, A.Number):
        return norm_num(-e.operand.value)
    return None


def _builtin_of(e):
    """Resolve `math.sign`, `debug`, `game.GetService`, ... to a Builtin."""
    if isinstance(e, A.Name):
        return Builtin(e.name)
    if isinstance(e, A.Index) and e.dot and isinstance(e.key, A.String):
        base = _builtin_of(e.obj)
        if base is not None:
            return Builtin(f"{base.name}.{e.key.value.decode('latin-1')}")
    return None


def extract_prelude(tree: A.Block) -> dict:
    """`local a0 = bit32.band` style aliases at the top of the file."""
    out = {}
    for st in tree.stmts:
        if isinstance(st, A.LocalAssign) and len(st.names) == 1 and len(st.values) == 1:
            b = _builtin_of(st.values[0])
            if b is not None and "." in b.name:
                out[st.names[0]] = b
    return out


def find_const_table(tree: A.Block):
    """Locate `aX = { ... }`: the largest array-style table constructor."""
    best = None
    for st in tree.stmts:
        cand = None
        if isinstance(st, A.Assign) and len(st.targets) == 1 and len(st.values) == 1 \
                and isinstance(st.targets[0], A.Name) and isinstance(st.values[0], A.Table):
            cand = (st.targets[0].name, st.values[0], st)
        elif isinstance(st, A.LocalAssign) and len(st.names) == 1 and len(st.values) == 1 \
                and isinstance(st.values[0], A.Table):
            cand = (st.names[0], st.values[0], st)
        if cand and (best is None or len(cand[1].array_items) > len(best[1].array_items)):
            best = cand
    return best


def build_consts(tbl: A.Table, prelude: dict) -> dict:
    ev = ConstEvaluator(lookup=lambda n: prelude.get(n, UNKNOWN))
    consts = {}
    for i, item in enumerate(tbl.array_items, start=1):
        v = ev.eval(item)
        if v is UNKNOWN:
            b = _builtin_of(item)
            v = b if b is not None else UNKNOWN
        consts[i] = v
    return consts


# ------------------------------------------------------------- dispatcher scan

def find_dispatcher(tree: A.Block):
    """Return (while_node, state_var, remap_expr, body_stmts)."""
    for st in tree.stmts:
        if isinstance(st, A.While) and isinstance(st.cond, A.TrueLit):
            body = st.body.stmts
            if not body:
                continue
            first = body[0]
            if isinstance(first, A.Assign) and len(first.targets) == 1 and \
                    isinstance(first.targets[0], A.Name):
                var = first.targets[0].name
                names = {n.name for n in A.walk(first.values[0]) if isinstance(n, A.Name)}
                if var in names:
                    return st, var, first.values[0], body[1:]
            # dispatcher without re-mapping
            return st, _guess_state_var(st), None, body
    return None


def _guess_state_var(wh: A.While) -> str:
    counts: dict[str, int] = {}
    for n in A.walk(wh):
        if isinstance(n, A.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], A.Name):
            counts[n.targets[0].name] = counts.get(n.targets[0].name, 0) + 1
    return max(counts, key=counts.get) if counts else ""


def collect_state_ids(wh: A.While, var: str) -> set:
    """Every numeric value ever assigned to the state variable."""
    ids = set()
    for n in A.walk(wh):
        if isinstance(n, A.Assign) and len(n.targets) == 1 and \
                isinstance(n.targets[0], A.Name) and n.targets[0].name == var:
            for v in _numeric_leaves(n.values[0]):
                ids.add(v)
    return ids


def _numeric_leaves(e):
    v = _num(e)
    if v is not None:
        return [v]
    if isinstance(e, A.IfExpr):
        out = []
        for _, val in e.branches:
            out.extend(_numeric_leaves(val))
        out.extend(_numeric_leaves(e.orelse))
        return out
    if isinstance(e, A.Paren):
        return _numeric_leaves(e.inner)
    return []


def resolve_state_body(stmts: list, var: str, raw: int) -> list:
    """Walk the dispatcher's search tree with the state variable pinned to `raw`."""
    ev = ConstEvaluator(lookup=lambda n: raw if n == var else UNKNOWN)
    out: list = []
    for st in stmts:
        if isinstance(st, A.Do):
            out.extend(resolve_state_body(st.body.stmts, var, raw))
            continue
        if isinstance(st, A.If):
            taken = None
            decidable = True
            for cond, blk in st.branches:
                t = truthy(ev.eval(cond))
                if t is UNKNOWN:
                    decidable = False
                    break
                if t:
                    taken = blk
                    break
            if not decidable:
                out.append(st)
                continue
            if taken is None:
                taken = st.orelse
            if taken is not None:
                out.extend(resolve_state_body(taken.stmts, var, raw))
            continue
        out.append(st)
        if isinstance(st, (A.Break, A.Continue, A.Return)):
            break
    return out


def split_terminator(stmts: list, var: str):
    """Separate a state's real statements from its `state = ...` terminator."""
    body: list = []
    term = ("exit",)
    for st in stmts:
        if isinstance(st, A.Break):
            term = ("exit",)
            break
        if isinstance(st, A.Continue):
            break
        if isinstance(st, A.Assign) and len(st.targets) == 1 and \
                isinstance(st.targets[0], A.Name) and st.targets[0].name == var:
            e = st.values[0]
            n = _num(e)
            if n is not None:
                term = ("goto", n)
            elif isinstance(e, A.IfExpr) and len(e.branches) == 1:
                a = _num(e.branches[0][1])
                b = _num(e.orelse)
                if a is not None and b is not None:
                    term = ("branch", e.branches[0][0], a, b)
                else:
                    term = ("dynamic", e)
            else:
                term = ("dynamic", e)
            continue
        body.append(st)
    return body, term


# ------------------------------------------------------------------- the pass

class Devirtualizer:
    def __init__(self, tree: A.Block):
        self.tree = tree
        self.prog = Program()

    def run(self) -> Program:
        p = self.prog
        p.prelude = extract_prelude(self.tree)
        found = find_const_table(self.tree)
        if not found:
            raise RuntimeError("no luast constant pool found — is this a luast script?")
        p.table_var, tbl_node, self.tbl_stmt = found
        p.consts = build_consts(tbl_node, p.prelude)

        disp = find_dispatcher(self.tree)
        if not disp:
            raise RuntimeError("no `while true do ... end` dispatcher found")
        self.wh, p.state_var, self.remap, self.disp_body = disp

        p.entry = self._find_entry()
        self._extract_mix()
        self._build_states()
        return p

    # -------------------------------------------------- helpers
    def _remap(self, sid: int) -> int:
        if self.remap is None:
            return sid
        ev = ConstEvaluator(lookup=lambda n: sid if n == self.prog.state_var else UNKNOWN)
        v = ev.eval(self.remap)
        return int(v) if is_number(v) else sid

    def _find_entry(self) -> int:
        """The last `state = <number>` before the dispatcher loop."""
        entry = None
        for st in self.tree.stmts:
            if st is self.wh:
                break
            for n in A.walk(st):
                if isinstance(n, A.Assign) and len(n.targets) == 1 and \
                        isinstance(n.targets[0], A.Name) and \
                        n.targets[0].name == self.prog.state_var:
                    v = _num(n.values[0])
                    if v is not None:
                        entry = v
        if entry is None:
            raise RuntimeError("could not find the dispatcher's initial state")
        return entry

    def _extract_mix(self):
        """Read the key-derivation pipeline + LCG constants out of the AST."""
        for fn in A.walk(self.wh):
            if not isinstance(fn, A.Function) or len(fn.params) != 1:
                continue
            ops = self._mix_ops(fn)
            if len(ops) >= 4:
                self.prog.mix_ops = ops
                break
        for n in A.walk(self.wh):
            if isinstance(n, A.BinOp) and n.op == "%" and _num(n.right) == 4294967296:
                inner = n.left
                if isinstance(inner, A.Paren):
                    inner = inner.inner
                if isinstance(inner, A.BinOp) and inner.op == "+":
                    mul_node, add_node = inner.left, inner.right
                    add = _num(add_node)
                    if isinstance(mul_node, A.BinOp) and mul_node.op == "*" and add is not None:
                        mul = _num(mul_node.right)
                        if mul is not None and isinstance(mul_node.left, A.Name):
                            self.prog.lcg = (int(mul), int(add))
                            return

    def _mix_ops(self, fn: A.Function) -> list:
        var = fn.params[0]
        ops = []
        for st in fn.body.stmts:
            if not (isinstance(st, A.Assign) and len(st.targets) == 1
                    and isinstance(st.targets[0], A.Name)
                    and st.targets[0].name == var):
                continue
            e = st.values[0]
            if isinstance(e, A.BinOp) and e.op == "%" and _num(e.right) == 4294967296:
                inner = e.left.inner if isinstance(e.left, A.Paren) else e.left
                if isinstance(inner, A.BinOp) and inner.op == "+":
                    c = _num(inner.right)
                    if c is not None:
                        ops.append(("add", int(c)))
                        continue
            if isinstance(e, A.Call):
                b = _builtin_of(e.func)
                if b is None:
                    continue
                name = self.prog.prelude.get(b.name, b).name if isinstance(b, Builtin) else ""
                name = b.name if "." in b.name else self.prog.prelude.get(b.name, b).name
                if name == "bit32.bxor" and len(e.args) == 2:
                    sub = e.args[1]
                    if isinstance(sub, A.Call):
                        sb = _builtin_of(sub.func)
                        sname = sb.name if sb and "." in sb.name else (
                            self.prog.prelude.get(sb.name).name if sb and sb.name in self.prog.prelude else "")
                        k = _num(sub.args[1]) if len(sub.args) == 2 else None
                        if k is not None and sname == "bit32.rshift":
                            ops.append(("xorshr", int(k)))
                            continue
                        if k is not None and sname == "bit32.lshift":
                            ops.append(("xorshl", int(k)))
                            continue
                if name == "bit32.lrotate" and len(e.args) == 2:
                    k = _num(e.args[1])
                    if k is not None:
                        ops.append(("rotl", int(k)))
                        continue
        return ops

    # -------------------------------------------------- state extraction
    def _build_states(self):
        p = self.prog
        ids = collect_state_ids(self.wh, p.state_var)
        ids.add(p.entry)
        for sid in sorted(ids):
            raw = self._remap(sid)
            stmts = resolve_state_body(self.disp_body, p.state_var, raw)
            body, term = split_terminator(stmts, p.state_var)
            p.states[sid] = State(sid=sid, raw=raw, stmts=body, term=term)
        self._mark_reachable()

    def _mark_reachable(self):
        p = self.prog
        seen = set()
        stack = [p.entry]
        while stack:
            s = stack.pop()
            if s in seen or s not in p.states:
                continue
            seen.add(s)
            st = p.states[s]
            st.reachable = True
            t = st.term
            if t[0] == "goto":
                stack.append(t[1])
            elif t[0] == "branch":
                stack.extend([t[2], t[3]])


def devirtualize(tree: A.Block) -> Program:
    return Devirtualizer(tree).run()
