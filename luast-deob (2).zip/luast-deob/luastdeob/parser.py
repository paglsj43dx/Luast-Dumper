"""Recursive-descent parser for the Lua 5.1 + Luau subset luast emits."""
from __future__ import annotations

from .lexer import Token, tokenize, LuaSyntaxError
from . import ast_nodes as A

# binary operator precedence: op -> (left, right)
BINPRI = {
    "or": (1, 1), "and": (2, 2),
    "<": (3, 3), ">": (3, 3), "<=": (3, 3), ">=": (3, 3), "~=": (3, 3), "==": (3, 3),
    "..": (9, 8),                       # right associative
    "+": (10, 10), "-": (10, 10),
    "*": (11, 11), "/": (11, 11), "//": (11, 11), "%": (11, 11),
    "^": (14, 13),                      # right associative
}
UNARY_PRI = 12

COMPOUND_OPS = {"+=": "+", "-=": "-", "*=": "*", "/=": "/", "%=": "%",
                "^=": "^", "..=": "..", "//=": "//"}

BLOCK_ENDERS = {"end", "else", "elseif", "until"}


class Parser:
    def __init__(self, src: str):
        self.toks = tokenize(src)
        self.i = 0

    # ---------------- token helpers ----------------
    @property
    def cur(self) -> Token:
        return self.toks[self.i]

    def la(self, n: int = 1) -> Token:
        j = min(self.i + n, len(self.toks) - 1)
        return self.toks[j]

    def next(self) -> Token:
        t = self.toks[self.i]
        self.i += 1
        return t

    def check(self, kind: str, value=None) -> bool:
        return self.cur.is_(kind, value)

    def accept(self, kind: str, value=None) -> Token | None:
        if self.check(kind, value):
            return self.next()
        return None

    def expect(self, kind: str, value=None) -> Token:
        if not self.check(kind, value):
            got = f"{self.cur.kind} {self.cur.value!r}"
            want = value if value is not None else kind
            raise LuaSyntaxError(f"expected {want!r} but got {got} at line {self.cur.line}")
        return self.next()

    # ---------------- entry ----------------
    def parse_chunk(self) -> A.Block:
        blk = self.parse_block()
        self.expect("eof")
        return blk

    def parse_block(self) -> A.Block:
        line = self.cur.line
        stmts: list[A.Node] = []
        while True:
            if self.cur.kind == "eof":
                break
            if self.cur.kind == "keyword" and self.cur.value in BLOCK_ENDERS:
                break
            if self.accept("symbol", ";"):
                continue
            # `continue` is contextual in Luau
            if self.cur.kind == "name" and self.cur.value == "continue" and \
                    not self._starts_expression_continuation():
                self.next()
                stmts.append(A.Continue(line=self.cur.line))
                continue
            st = self.parse_statement()
            stmts.append(st)
            if isinstance(st, (A.Return, A.Break)):
                # last statement in a block
                while self.accept("symbol", ";"):
                    pass
                break
        return A.Block(stmts, line=line)

    def _starts_expression_continuation(self) -> bool:
        """Disambiguate `continue` used as an identifier (e.g. `continue = 1`)."""
        nxt = self.la(1)
        return nxt.kind == "symbol" and nxt.value in {"=", ".", "[", "(", ":", ",", "+=", "-="}

    # ---------------- statements ----------------
    def parse_statement(self) -> A.Node:
        t = self.cur
        line = t.line
        if t.kind == "keyword":
            kw = t.value
            if kw == "local":
                return self.parse_local()
            if kw == "if":
                return self.parse_if()
            if kw == "while":
                self.next()
                cond = self.parse_expr()
                self.expect("keyword", "do")
                body = self.parse_block()
                self.expect("keyword", "end")
                return A.While(cond, body, line=line)
            if kw == "do":
                self.next()
                body = self.parse_block()
                self.expect("keyword", "end")
                return A.Do(body, line=line)
            if kw == "for":
                return self.parse_for()
            if kw == "repeat":
                self.next()
                body = self.parse_block()
                self.expect("keyword", "until")
                cond = self.parse_expr()
                return A.Repeat(body, cond, line=line)
            if kw == "function":
                self.next()
                target, is_method = self.parse_funcname()
                fn = self.parse_funcbody(line, is_method)
                return A.FunctionStat(target, fn, False, is_method, line=line)
            if kw == "return":
                self.next()
                vals: list[A.Node] = []
                if not (self.cur.kind == "eof"
                        or (self.cur.kind == "keyword" and self.cur.value in BLOCK_ENDERS)
                        or self.check("symbol", ";")):
                    vals = self.parse_exprlist()
                return A.Return(vals, line=line)
            if kw == "break":
                self.next()
                return A.Break(line=line)
        # expression statement: call or assignment
        return self.parse_exprstat()

    def parse_local(self) -> A.Node:
        line = self.expect("keyword", "local").line
        if self.accept("keyword", "function"):
            name = self.expect("name").value
            fn = self.parse_funcbody(line, False)
            fn.name = name
            return A.FunctionStat(A.Name(name, line=line), fn, True, False, line=line)
        names = [self.parse_attrib_name()]
        while self.accept("symbol", ","):
            names.append(self.parse_attrib_name())
        values: list[A.Node] = []
        if self.accept("symbol", "="):
            values = self.parse_exprlist()
        return A.LocalAssign(names, values, line=line)

    def parse_attrib_name(self) -> str:
        name = self.expect("name").value
        self.skip_type_annotation()
        return name

    def skip_type_annotation(self) -> None:
        """Luau type annotations are irrelevant to us; consume and discard."""
        if not self.check("symbol", ":"):
            return
        self.next()
        depth = 0
        while True:
            t = self.cur
            if t.kind == "eof":
                return
            if t.kind == "symbol":
                if t.value in "({[":
                    depth += 1
                elif t.value in ")}]":
                    if depth == 0:
                        return
                    depth -= 1
                elif depth == 0 and t.value in {",", ";", "="}:
                    return
            if depth == 0 and t.kind == "keyword" and t.value in {
                    "do", "then", "end", "local", "return", "while", "if", "for"}:
                return
            self.next()

    def parse_funcname(self):
        name = self.expect("name")
        expr: A.Node = A.Name(name.value, line=name.line)
        is_method = False
        while True:
            if self.accept("symbol", "."):
                k = self.expect("name")
                expr = A.Index(expr, A.String(k.value.encode(), line=k.line), True, line=k.line)
            elif self.accept("symbol", ":"):
                k = self.expect("name")
                expr = A.Index(expr, A.String(k.value.encode(), line=k.line), True, line=k.line)
                is_method = True
                break
            else:
                break
        return expr, is_method

    def parse_funcbody(self, line: int, is_method: bool) -> A.Function:
        # optional generic type params <T, U>
        if self.check("symbol", "<"):
            depth = 0
            while True:
                t = self.next()
                if t.kind == "symbol" and t.value == "<":
                    depth += 1
                elif t.kind == "symbol" and t.value == ">":
                    depth -= 1
                    if depth == 0:
                        break
                elif t.kind == "eof":
                    break
        self.expect("symbol", "(")
        params: list[str] = ["self"] if is_method else []
        is_vararg = False
        if not self.check("symbol", ")"):
            while True:
                if self.accept("symbol", "..."):
                    is_vararg = True
                    self.skip_type_annotation()
                    break
                params.append(self.parse_attrib_name())
                if not self.accept("symbol", ","):
                    break
        self.expect("symbol", ")")
        self.skip_type_annotation()      # return type
        body = self.parse_block()
        self.expect("keyword", "end")
        return A.Function(params, is_vararg, body, line=line)

    def parse_if(self) -> A.If:
        line = self.expect("keyword", "if").line
        branches = []
        cond = self.parse_expr()
        self.expect("keyword", "then")
        branches.append((cond, self.parse_block()))
        orelse = None
        while True:
            if self.accept("keyword", "elseif"):
                c = self.parse_expr()
                self.expect("keyword", "then")
                branches.append((c, self.parse_block()))
            elif self.accept("keyword", "else"):
                orelse = self.parse_block()
                break
            else:
                break
        self.expect("keyword", "end")
        return A.If(branches, orelse, line=line)

    def parse_for(self) -> A.Node:
        line = self.expect("keyword", "for").line
        first = self.parse_attrib_name()
        if self.accept("symbol", "="):
            start = self.parse_expr()
            self.expect("symbol", ",")
            stop = self.parse_expr()
            step = self.parse_expr() if self.accept("symbol", ",") else None
            self.expect("keyword", "do")
            body = self.parse_block()
            self.expect("keyword", "end")
            return A.NumericFor(first, start, stop, step, body, line=line)
        names = [first]
        while self.accept("symbol", ","):
            names.append(self.parse_attrib_name())
        self.expect("keyword", "in")
        exprs = self.parse_exprlist()
        self.expect("keyword", "do")
        body = self.parse_block()
        self.expect("keyword", "end")
        return A.GenericFor(names, exprs, body, line=line)

    def parse_exprstat(self) -> A.Node:
        line = self.cur.line
        first = self.parse_suffixed()
        if self.cur.kind == "symbol" and self.cur.value in COMPOUND_OPS:
            op = COMPOUND_OPS[self.next().value]
            val = self.parse_expr()
            return A.CompoundAssign(op, first, val, line=line)
        if self.check("symbol", "=") or self.check("symbol", ","):
            targets = [first]
            while self.accept("symbol", ","):
                targets.append(self.parse_suffixed())
            self.expect("symbol", "=")
            values = self.parse_exprlist()
            return A.Assign(targets, values, line=line)
        if isinstance(first, (A.Call, A.MethodCall)):
            return A.CallStat(first, line=line)
        raise LuaSyntaxError(f"syntax error near line {line}: expression is not a statement")

    # ---------------- expressions ----------------
    def parse_exprlist(self) -> list[A.Node]:
        out = [self.parse_expr()]
        while self.accept("symbol", ","):
            out.append(self.parse_expr())
        return out

    def parse_expr(self, limit: int = 0) -> A.Node:
        line = self.cur.line
        if (self.cur.kind == "keyword" and self.cur.value == "not") or \
           (self.cur.kind == "symbol" and self.cur.value in {"-", "#"}):
            op = self.next().value
            operand = self.parse_expr(UNARY_PRI)
            left: A.Node = A.UnOp(op, operand, line=line)
        else:
            left = self.parse_simple()
        while True:
            t = self.cur
            op = None
            if t.kind == "symbol" and t.value in BINPRI:
                op = t.value
            elif t.kind == "keyword" and t.value in ("and", "or"):
                op = t.value
            if op is None:
                break
            lp, rp = BINPRI[op]
            if lp <= limit:
                break
            self.next()
            right = self.parse_expr(rp)
            left = A.BinOp(op, left, right, line=t.line)
        # `::` type cast
        while self.accept("symbol", "::"):
            self.skip_cast_type()
        return left

    def skip_cast_type(self) -> None:
        depth = 0
        while True:
            t = self.cur
            if t.kind == "eof":
                return
            if t.kind == "symbol":
                if t.value in "({[<":
                    depth += 1
                elif t.value in ")}]>":
                    if depth == 0:
                        return
                    depth -= 1
                elif depth == 0 and t.value in {",", ";"} or (depth == 0 and t.value in BINPRI):
                    return
            if depth == 0 and t.kind == "keyword":
                return
            self.next()

    def parse_simple(self) -> A.Node:
        t = self.cur
        line = t.line
        if t.kind == "number":
            self.next()
            return A.Number(t.value, t.raw, line=line)
        if t.kind == "string":
            self.next()
            return A.String(t.value, line=line)
        if t.kind == "keyword":
            if t.value == "nil":
                self.next(); return A.Nil(line=line)
            if t.value == "true":
                self.next(); return A.TrueLit(line=line)
            if t.value == "false":
                self.next(); return A.FalseLit(line=line)
            if t.value == "function":
                self.next(); return self.parse_funcbody(line, False)
            if t.value == "if":
                return self.parse_ifexpr()
        if t.kind == "symbol":
            if t.value == "...":
                self.next(); return A.VarArg(line=line)
            if t.value == "{":
                return self.parse_table()
        return self.parse_suffixed()

    def parse_ifexpr(self) -> A.IfExpr:
        line = self.expect("keyword", "if").line
        branches = []
        cond = self.parse_expr()
        self.expect("keyword", "then")
        branches.append((cond, self.parse_expr()))
        while self.accept("keyword", "elseif"):
            c = self.parse_expr()
            self.expect("keyword", "then")
            branches.append((c, self.parse_expr()))
        self.expect("keyword", "else")
        orelse = self.parse_expr()
        return A.IfExpr(branches, orelse, line=line)

    def parse_table(self) -> A.Table:
        line = self.expect("symbol", "{").line
        arr: list[A.Node] = []
        hash_: list[tuple[A.Node, A.Node]] = []
        while not self.check("symbol", "}"):
            if self.check("symbol", "["):
                self.next()
                k = self.parse_expr()
                self.expect("symbol", "]")
                self.expect("symbol", "=")
                hash_.append((k, self.parse_expr()))
            elif self.cur.kind == "name" and self.la(1).is_("symbol", "="):
                k = self.next()
                self.next()
                hash_.append((A.String(k.value.encode(), line=k.line), self.parse_expr()))
            else:
                arr.append(self.parse_expr())
            if not (self.accept("symbol", ",") or self.accept("symbol", ";")):
                break
        self.expect("symbol", "}")
        return A.Table(arr, hash_, line=line)

    def parse_primary(self) -> A.Node:
        t = self.cur
        if t.kind == "name":
            self.next()
            return A.Name(t.value, line=t.line)
        if t.is_("symbol", "("):
            self.next()
            e = self.parse_expr()
            self.expect("symbol", ")")
            return A.Paren(e, line=t.line)
        raise LuaSyntaxError(
            f"unexpected {t.kind} {t.value!r} at line {t.line}")

    def parse_suffixed(self) -> A.Node:
        expr = self.parse_primary()
        while True:
            t = self.cur
            if t.is_("symbol", "."):
                self.next()
                k = self.expect("name")
                expr = A.Index(expr, A.String(k.value.encode(), line=k.line), True, line=k.line)
            elif t.is_("symbol", "["):
                self.next()
                k = self.parse_expr()
                self.expect("symbol", "]")
                expr = A.Index(expr, k, False, line=t.line)
            elif t.is_("symbol", ":"):
                # method call  obj:name(args)
                if self.la(1).kind == "name" and self.la(2).kind in ("symbol", "string") and \
                        (self.la(2).is_("symbol", "(") or self.la(2).is_("symbol", "{")
                         or self.la(2).kind == "string"):
                    self.next()
                    m = self.expect("name").value
                    args = self.parse_args()
                    expr = A.MethodCall(expr, m, args, line=t.line)
                else:
                    break
            elif t.is_("symbol", "(") or t.is_("symbol", "{") or t.kind == "string":
                args = self.parse_args()
                expr = A.Call(expr, args, line=t.line)
            else:
                break
        return expr

    def parse_args(self) -> list[A.Node]:
        t = self.cur
        if t.kind == "string":
            self.next()
            return [A.String(t.value, line=t.line)]
        if t.is_("symbol", "{"):
            return [self.parse_table()]
        self.expect("symbol", "(")
        args: list[A.Node] = []
        if not self.check("symbol", ")"):
            args = self.parse_exprlist()
        self.expect("symbol", ")")
        return args


def parse(src: str) -> A.Block:
    return Parser(src).parse_chunk()
