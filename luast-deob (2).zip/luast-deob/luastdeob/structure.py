"""Recover structured control flow (loops / if-else) from the state graph."""
from __future__ import annotations

from dataclasses import dataclass, field

from . import ast_nodes as A
from .devirt import Program

EXIT = "__exit__"


# ----------------------------------------------------------------- graph utils

def successors(prog: Program, sid):
    t = prog.states[sid].term
    if t[0] == "goto":
        return [t[1]] if t[1] in prog.states else [EXIT]
    if t[0] == "branch":
        a = t[2] if t[2] in prog.states else EXIT
        b = t[3] if t[3] in prog.states else EXIT
        return [a, b]
    return [EXIT]


def build_preds(prog: Program) -> dict:
    preds = {s: set() for s in prog.states}
    preds[EXIT] = set()
    for s in prog.states:
        for t in successors(prog, s):
            preds.setdefault(t, set()).add(s)
    return preds


def merge_chains(prog: Program) -> int:
    """Splice `A: goto B` into A whenever B has no other way in."""
    merged = 0
    changed = True
    while changed:
        changed = False
        preds = build_preds(prog)
        for sid in list(prog.states):
            st = prog.states.get(sid)
            if st is None or st.term[0] != "goto":
                continue
            nxt = st.term[1]
            if nxt == sid or nxt not in prog.states or nxt == prog.entry:
                continue
            if preds.get(nxt, set()) != {sid}:
                continue
            tgt = prog.states[nxt]
            st.stmts = st.stmts + tgt.stmts
            st.term = tgt.term
            del prog.states[nxt]
            merged += 1
            changed = True
            break
    return merged


def dominators(prog: Program) -> dict:
    nodes = list(prog.states) + [EXIT]
    preds = build_preds(prog)
    entry = prog.entry
    dom = {n: set(nodes) for n in nodes}
    dom[entry] = {entry}
    changed = True
    while changed:
        changed = False
        for n in nodes:
            if n == entry:
                continue
            ps = [p for p in preds.get(n, ()) if p in dom]
            new = set(nodes) if not ps else set.intersection(*[dom[p] for p in ps])
            new = new | {n}
            if new != dom[n]:
                dom[n] = new
                changed = True
    return dom


def post_dominators(prog: Program) -> dict:
    nodes = list(prog.states) + [EXIT]
    succ = {n: (successors(prog, n) if n != EXIT else []) for n in nodes}
    pdom = {n: set(nodes) for n in nodes}
    pdom[EXIT] = {EXIT}
    changed = True
    while changed:
        changed = False
        for n in nodes:
            if n == EXIT:
                continue
            ss = [s for s in succ[n] if s in pdom]
            new = set(nodes) if not ss else set.intersection(*[pdom[s] for s in ss])
            new = new | {n}
            if new != pdom[n]:
                pdom[n] = new
                changed = True
    return pdom


def find_loops(prog: Program, dom: dict) -> dict:
    """header -> set of nodes in its natural loop."""
    preds = build_preds(prog)
    loops: dict = {}
    for n in prog.states:
        for s in successors(prog, n):
            if s in prog.states and s in dom.get(n, set()):
                body = {s}
                stack = [n]
                while stack:
                    x = stack.pop()
                    if x in body:
                        continue
                    body.add(x)
                    stack.extend(p for p in preds.get(x, ()) if p in prog.states)
                loops.setdefault(s, set()).update(body)
    return loops


# ------------------------------------------------------------------- emitter

@dataclass
class LoopCtx:
    header: object
    exit: object
    body: set


class Structurer:
    def __init__(self, prog: Program):
        self.prog = prog
        self.dom = dominators(prog)
        self.pdom = post_dominators(prog)
        self.loops = find_loops(prog, self.dom)
        self.preds = build_preds(prog)
        self.emitted_loops: set = set()
        self.unresolved: list = []

    # -------------------------------------------------- helpers
    def ipdom(self, n):
        """Immediate post-dominator of n."""
        cands = self.pdom.get(n, set()) - {n}
        if not cands:
            return EXIT
        best = None
        for c in cands:
            if best is None or best in self.pdom.get(c, set()):
                best = c
        return best if best is not None else EXIT

    def loop_of(self, n, stack):
        for ctx in reversed(stack):
            if n in ctx.body:
                return ctx
        return None

    # -------------------------------------------------- main walk
    def emit(self, start, stop, stack, guard=0):
        out: list = []
        n = start
        seen = set()
        while n is not None and n != stop and n != EXIT:
            if n in seen or guard > 4000:
                self.unresolved.append(n)
                out.append(A.Comment(f"[deobf] unstructured jump to state {n}"))
                break
            seen.add(n)

            # a jump to an enclosing loop header / exit becomes continue / break
            ctl = self._loop_control(n, stack, out)
            if ctl is not None:
                out.extend(ctl)
                break

            if n in self.loops and n not in self.emitted_loops:
                loop_stmt, after = self.emit_loop(n, stack, guard + 1)
                out.append(loop_stmt)
                n = after
                continue

            st = self.prog.states.get(n)
            if st is None:
                break
            out.extend(st.stmts)
            t = st.term
            if t[0] == "goto":
                n = t[1] if t[1] in self.prog.states else EXIT
            elif t[0] == "branch":
                cond, a, b = t[1], t[2], t[3]
                a = a if a in self.prog.states else EXIT
                b = b if b in self.prog.states else EXIT
                join = self.ipdom(n)
                if join == n:
                    join = EXIT
                then_blk = self.emit(a, join, stack, guard + 1) if a != join else []
                else_blk = self.emit(b, join, stack, guard + 1) if b != join else []
                if not then_blk and else_blk:
                    cond = _negate(cond)
                    then_blk, else_blk = else_blk, []
                out.append(A.If([(cond, A.Block(then_blk))],
                                A.Block(else_blk) if else_blk else None, line=st.stmts[0].line
                                if st.stmts else 0))
                n = join
            else:
                n = EXIT
        return out

    def _loop_control(self, n, stack, out):
        for ctx in reversed(stack):
            if n == ctx.header:
                return [A.Continue()] if out or True else []
            if n == ctx.exit:
                return [A.Break()]
        return None

    def emit_loop(self, header, stack, guard):
        body_nodes = self.loops[header]
        self.emitted_loops.add(header)
        hdr = self.prog.states[header]

        exits = set()
        for x in body_nodes:
            for s in successors(self.prog, x):
                if s not in body_nodes:
                    exits.add(s)
        exit_node = None

        # `while cond do ... end`: header tests and one arm leaves the loop
        if hdr.term[0] == "branch" and not hdr.stmts:
            cond, a, b = hdr.term[1], hdr.term[2], hdr.term[3]
            a = a if a in self.prog.states else EXIT
            b = b if b in self.prog.states else EXIT
            inside, outside, negate = None, None, False
            if a in body_nodes and b not in body_nodes:
                inside, outside = a, b
            elif b in body_nodes and a not in body_nodes:
                inside, outside, negate = b, a, True
            if inside is not None:
                exit_node = outside
                ctx = LoopCtx(header, outside, body_nodes)
                body = self.emit(inside, header, stack + [ctx], guard)
                body = _strip_trailing_continue(body)
                c = _negate(cond) if negate else cond
                return A.While(c, A.Block(body), line=hdr.line if hasattr(hdr, "line") else 0), exit_node

        # generic: `while true do ... end` with explicit breaks
        exit_node = next((e for e in exits if e != header), EXIT)
        ctx = LoopCtx(header, exit_node, body_nodes)
        body = self.emit(header, None, stack + [ctx], guard)
        body = _strip_trailing_continue(body)
        return A.While(A.TrueLit(), A.Block(body)), exit_node


def _strip_trailing_continue(stmts):
    while stmts and isinstance(stmts[-1], A.Continue):
        stmts = stmts[:-1]
    return stmts


def _negate(cond):
    if isinstance(cond, A.BinOp):
        flip = {"==": "~=", "~=": "==", "<": ">=", ">=": "<", ">": "<=", "<=": ">"}
        if cond.op in flip:
            return A.BinOp(flip[cond.op], cond.left, cond.right, line=cond.line)
    if isinstance(cond, A.UnOp) and cond.op == "not":
        return cond.operand
    return A.UnOp("not", cond, line=getattr(cond, "line", 0))


def structure(prog: Program) -> A.Block:
    merge_chains(prog)
    s = Structurer(prog)
    stmts = s.emit(prog.entry, None, [])
    return A.Block(stmts)
