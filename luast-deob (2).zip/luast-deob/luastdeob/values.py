"""Runtime value model used by the constant evaluator."""
from __future__ import annotations

from dataclasses import dataclass


class _Sentinel:
    __slots__ = ("label",)

    def __init__(self, label: str):
        self.label = label

    def __repr__(self) -> str:
        return self.label


NIL = _Sentinel("nil")
UNKNOWN = _Sentinel("<unknown>")     # not statically determinable (lattice bottom)
UNDEF = _Sentinel("<undef>")         # lattice top: not yet reached


@dataclass(frozen=True)
class Builtin:
    """A reference to a standard library / Roblox global, e.g. `print`."""
    name: str

    def __repr__(self) -> str:
        return f"<{self.name}>"


@dataclass(frozen=True)
class ConstTable:
    """Handle for luast's big constant array."""
    ident: str = "K"

    def __repr__(self) -> str:
        return f"<consttable {self.ident}>"


def is_number(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def is_string(v) -> bool:
    return isinstance(v, bytes)


def truthy(v):
    """Lua truthiness; returns UNKNOWN when undecidable."""
    if v is UNKNOWN or v is UNDEF:
        return UNKNOWN
    if v is NIL or v is False:
        return False
    return True


def lua_tostring(v) -> str:
    if v is NIL:
        return "nil"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, bytes):
        return v.decode("latin-1")
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def norm_num(v):
    """Keep integral doubles as Python ints so table indices behave."""
    if isinstance(v, float) and v.is_integer() and abs(v) < 2 ** 53:
        return int(v)
    return v
