# luast-deob

A static deobfuscator for Luau scripts produced by **luast v1.0.x** (`luast.clv.cloud`).

It parses the obfuscated script, rebuilds the constant pool, decrypts the string
constants, collapses the flattened state machine back into real control flow,
deletes the anti-tamper scaffolding, and prints readable Luau.

```
$ python3 deobf.py samples/hello.obf.lua --stdout
for i = 1, 3 do
    print(i, "Hello from luast")
end
```

…recovered from 160 lines of this:

```lua
local aX; aX = { 668265263, 346665., '{"m":null,"t":"buffer","zbase64":"KLUv/SAa…"}', … }
local aj = nil; aj = 16; while true do aj = 12051. - aj; do if aj < 12011 then …
```

---

## Install

Python 3.10+. No hard dependencies, but two optional packages help a lot:

```bash
pip install -r requirements.txt   # numpy (fast key search), zstandard (payload blobs)
```

* **numpy** — makes the key search ~100× faster and memory-bounded. Without it a
  pure-Python fallback is used.
* **zstandard** — needed only to expand embedded `zbase64` buffer payloads.

## Usage

```bash
python3 deobf.py input.lua                  # writes input.deobf.lua
python3 deobf.py input.lua -o clean.lua
python3 deobf.py input.lua --stdout
python3 deobf.py input.lua --report         # analysis summary, no output file
python3 deobf.py input.lua --strings --candidates 10
python3 deobf.py input.lua --keep-dead      # keep anti-tamper code
python3 deobf.py input.lua --raw            # no renaming / for-loop rebuild
python3 deobf.py input.lua --debug          # constant pool + recovered state graph
cat input.lua | python3 deobf.py -
```

### Trying it on a new sample

```bash
python3 deobf.py new.lua --report     # 1. did it recognise the script?
python3 deobf.py new.lua --stdout     # 2. look at the output
python3 deobf.py new.lua --debug > dbg.txt   # 3. only if something looks wrong
```

What `--report` is telling you:

| Line | Healthy | Suspicious |
|---|---|---|
| `vm states` | live count far below decoded | live ≈ decoded (predicates did not fold) |
| `opaque branches` | tens to hundreds folded | `0` folded |
| `strings decrypted` | matches the string count you expect | `0`, or lots of `(!) ambiguous` |
| `anti-tamper` / `dead stores` | large numbers removed | `0` removed |

`--debug` prints the constant pool after the shuffle and every live state with its
statements and terminator — that is the view that tells you *where* a new build
diverges. `--raw` skips the cosmetic passes, which is useful for deciding whether
a problem is in the analysis or only in the pretty-printing.

Use it as a library:

```python
from luastdeob.pipeline import deobfuscate, format_report
source, report = deobfuscate(open("input.lua").read())
print(format_report(report))
```

Run the tests with `python3 tests/test_deob.py` (or `python3 -m pytest tests -q`).

---

## How luast protects a script

Worth writing down, because it drives every pass in the tool.

**1. Constant pool.** Every literal, global and library reference is hoisted into
one big array `aX = { … }`. Code refers to `aX[137]` instead of `1`, `aX[69]`
instead of `print`.

**2. Pool shuffle.** At startup the pool permutes itself with a few simultaneous
assignments, so a static reader who looks up `aX[57]` in the source array gets
the wrong entry:

```lua
bb[145], bb[67], bb[126] = bb[145], bb[126], bb[67]
```

**3. Control-flow flattening.** The original statements are spread across
numbered states of a `while true do … end` dispatcher. The state id is re-mapped
every iteration (`aj = 12051 - aj`) and dispatched through a nested binary search
tree, so consecutive states are nowhere near each other in the source.

**4. Opaque predicates.** Branches are guarded by conditions that always have the
same answer — `if ae == ae`, `if ae ~= ae`, and arithmetic identities like
`(an*c1 + ao*c2 + an*ao) % 2^32 == c3` where `an`/`ao` were just loaded from the
pool. Unreachable filler blocks are guarded with `0/0 == x` and `v*v < 0`.

**5. Anti-tamper accumulator.** A variable (`ae`) accumulates the results of
dozens of environment probes: `table.isfrozen(buffer)`, `#debug.info(f, "n")`,
`Font.fromName(...)` metrics, `Vector2int16.new(0,513) * 240`, and a
`pcall(HttpService.JSONDecode, …)` on an embedded zstd buffer blob. In a pristine
Roblox VM this lands on one exact number.

**6. String encryption keyed by that accumulator.** Each string is stored as
ciphertext plus a fixed random suffix (stripped at runtime). The key comes from
the accumulator:

```
seed = (current_state + ae) % M
K    = mix(seed)                       -- 24-step add / xor-shift / rotate pipeline
for each 4-byte block:  K = K*1597 + 51749 (mod 2^32);  plain = cipher - K
```

So if you hook a function, run outside Roblox, or patch anything, `ae` changes
and every string decrypts to garbage. That is the interesting part of the design.

---

## How the tool defeats it

**Strings without ever computing `ae`.** Reproducing the accumulator would mean
emulating Roblox exactly — brittle and version-dependent. Instead the tool
recovers the *keystream* directly. The key schedule is an LCG mod 2³², so byte
plane *p* of every round key depends only on the low `8(p+1)` bits of `K₁`. That
lets the key be lifted one byte-plane at a time, filtering against "the plaintext
must be printable", four passes of 256 candidates each instead of 2³² guesses.
It is environment independent and takes milliseconds.

For a 16-byte string this narrows 4.3 billion keys to a few hundred; a character
bigram model then picks the real one. Recovered keys are run back through the
inverted mix function to report the seed that produced them.

**Everything else is constant propagation.** Once the pool shuffle is replayed
and strings are literals, a sparse conditional constant propagation pass over the
state graph folds every opaque predicate (`x == x` is true for any non-NaN
number, and the arithmetic identities are computable), which turns the 117-state
graph into a handful of real basic blocks. Backward liveness then deletes the
tamper cluster — ordinary "is this name read anywhere?" DCE cannot, because those
statements feed each other and look mutually alive.

Finally the CFG is re-structured into `while`/`if` using dominator and
post-dominator analysis, counted loops are rebuilt into `for`, copies are
forward-substituted, and the leftover locals get readable names.

### Pipeline

| Stage | Module | What it does |
|---|---|---|
| lex / parse | `lexer.py`, `parser.py` | Luau subset: `+=`, `if…then…else` expressions, `continue`, `::` casts, type annotations |
| devirtualise | `devirt.py` | pool extraction, dispatcher decoding, state → CFG |
| pool shuffle | `analysis.py` | replays the permutation |
| strings | `crypto.py` | byte-plane key lift, scoring, mix inversion, zstd payloads |
| SCCP | `analysis.py` | constant propagation, opaque branch folding |
| cleanup | `cleanup.py` | tamper stripping, backward-liveness DCE |
| structuring | `structure.py` | dominators, natural loops, `if`/`while` recovery |
| polish | `polish.py` | copy propagation, `for` rebuild, method calls, renaming |

---

## Limitations — read this

* **Original names are gone.** luast discards them, so locals come back as
  `v1, v2, i, j`. Constants that the obfuscator folded (like `local n = 3`) get
  inlined at their use site. The result is *semantically* equivalent, not
  byte-identical to the input.
* **Very short strings are genuinely ambiguous.** A 4-byte ciphertext is
  reported as under-determined and left in place rather than guessed. Anything
  from ~7 bytes is recoverable but flagged; from ~12 bytes recovery is
  effectively unique. `--strings --candidates 10` lists the alternatives —
  always eyeball flagged ones.
* **Built and verified against one v1.0.1 sample.** The passes key off structure
  (pool shape, dispatcher shape, decryptor shape) rather than exact constants,
  and the mix pipeline and LCG constants are read out of the script rather than
  hardcoded, so other builds of the same version should work. Other versions may
  need adjustment — `--report` and `--raw` are the debugging aids.
* **Irreducible control flow** falls back to a `-- [deobf] unstructured jump`
  comment instead of producing wrong code.
* Anti-tamper removal assumes the probes are side-effect free, which holds for
  this obfuscator. `--keep-dead` preserves everything if you would rather check.

## Legal / intent

This is a reverse-engineering and script-analysis tool — the usual reasons for
wanting one are auditing Roblox scripts you have been asked to run, recovering
your own work, and malware analysis. Respect the licence and ownership of
anything you point it at.
