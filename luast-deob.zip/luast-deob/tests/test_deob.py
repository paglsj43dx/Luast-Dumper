"""Test suite for luast-deob.  Run with:  python3 -m pytest tests -q   (or plain python3 tests/test_deob.py)"""
from __future__ import annotations

import random
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from luastdeob.crypto import (DEFAULT_MIX, MASK, decrypt_with_key, recover_keys,
                              score_plaintext, seed_from_key, zstd_decompress)
from luastdeob.parser import parse
from luastdeob.pipeline import deobfuscate
from luastdeob.printer import to_source

SAMPLE = ROOT / "samples" / "hello.obf.lua"
MUL, ADD = 1597, 51749


# ------------------------------------------------------------------ helpers

def lua_encrypt(pt: bytes, k1: int) -> bytes:
    """Inverse of luast's decryptor, for round-trip testing."""
    plen = len(pt)
    if 1 <= plen <= 3:
        return bytes(((pt[i] + ((k1 >> (8 * i)) & 0xFF)) & 0xFF) for i in range(plen))
    buf = bytearray(pt + b"\x00" * (-plen % 4))
    k, n = k1, 0
    while n <= plen - 4:
        v = struct.unpack_from("<I", buf, n)[0]
        struct.pack_into("<I", buf, n, (v + k) & MASK)
        k = (k * MUL + ADD) & MASK
        n += 4
    if n < plen:
        j = 0
        while n < plen:
            buf[n] = (buf[n] + ((k >> (8 * j)) & 0xFF)) & 0xFF
            n += 1
            j += 1
    return bytes(buf[:plen])


def run_lua(src: str) -> list[str]:
    import lupa
    L = lupa.LuaRuntime(unpack_returned_tuples=True)
    out: list[str] = []
    L.globals().print = lambda *a: out.append(
        "\t".join("%g" % x if isinstance(x, (int, float)) else str(x) for x in a))
    L.execute(src)
    return out


# ------------------------------------------------------------------ tests

def test_parser_roundtrip():
    src = SAMPLE.read_text()
    a = to_source(parse(src))
    b = to_source(parse(a))
    assert a == b, "printer/parser round-trip is not stable"


def test_keystream_recovery_roundtrip():
    """Strings of a realistic length must come back exactly."""
    rng = random.Random(1234)
    texts = [
        b"Hello from luast",
        b"https://example.com/api/webhook?id=99",
        b"ReplicatedStorage",
        b"a much longer sentence that should pin the key down uniquely",
        b"Successfully loaded",
    ]
    for pt in texts:
        k1 = rng.randrange(1 << 32)
        ct = lua_encrypt(pt, k1)
        keys = recover_keys(ct, len(pt), MUL, ADD)
        assert k1 in keys, f"true key missing for {pt!r}"
        best = max(keys, key=lambda k: score_plaintext(
            decrypt_with_key(ct, len(pt), k, MUL, ADD)))
        got = decrypt_with_key(ct, len(pt), best, MUL, ADD)
        assert got == pt, f"scored the wrong candidate for {pt!r}: got {got!r}"


def test_true_key_always_survives_the_lift():
    """Even when ranking cannot pick it, the real key must be in the set."""
    rng = random.Random(99)
    for pt in (b"Players", b"Humanoid", b"Part name"):
        k1 = rng.randrange(1 << 32)
        ct = lua_encrypt(pt, k1)
        keys = recover_keys(ct, len(pt), MUL, ADD, limit=20_000_000)
        assert k1 in keys, f"lift lost the true key for {pt!r}"


def test_short_strings_are_flagged_not_guessed():
    """4-byte ciphertexts cannot be resolved; the tool must admit it."""
    from luastdeob.crypto import Underdetermined, shortlist
    ct = lua_encrypt(b"Part", 0x1234)
    try:
        shortlist(ct, 4, MUL, ADD)
    except Underdetermined:
        return
    raise AssertionError("a 4-byte string should be reported under-determined")


def test_ambiguity_is_reported():
    from luastdeob.crypto import decrypt_string
    ct = lua_encrypt(b"Players", 0x20001)
    r = decrypt_string(ct, 0, MUL, ADD)
    assert r is not None and r.ambiguous, "7-byte result should be flagged ambiguous"


def test_long_strings_are_unique():
    """8+ blocks should leave exactly one printable candidate."""
    pt = b"this is a reasonably long constant used inside a roblox script"
    ct = lua_encrypt(pt, 0xDEADBEEF)
    keys = recover_keys(ct, len(pt), MUL, ADD)
    assert len(keys) == 1 and keys[0] == 0xDEADBEEF


def test_short_tail_strings():
    """Lengths that are not a multiple of 4 exercise the tail path."""
    for pt in (b"abc", b"abcde", b"Players!", b"xy"):
        ct = lua_encrypt(pt, 0x12345678)
        got = decrypt_with_key(ct, len(pt), 0x12345678, MUL, ADD)
        assert got == pt, f"{pt!r} -> {got!r}"


def test_mix_is_invertible():
    for w in (0, 1, 0xFFFFFFFF, 0x780E5D65, 123456789):
        assert DEFAULT_MIX.invert(DEFAULT_MIX(w)) == w
    k1 = 0x780E5D65
    seed = seed_from_key(k1, MUL, ADD, DEFAULT_MIX)
    assert (DEFAULT_MIX(seed) * MUL + ADD) & MASK == k1


def test_zstd_payload():
    import base64
    blob = base64.b64decode("KLUv/SAavQAAosEEjUEREAAQARAAQTAQx+EREkVnAQA=")
    assert len(zstd_decompress(blob)) == 26


def test_end_to_end_recovers_program():
    text, rep = deobfuscate(SAMPLE.read_text())
    norm = " ".join(text.split())
    assert norm == 'for i = 1, 3 do print(i, "Hello from luast") end', text
    assert len(rep.strings) == 1
    assert rep.strings[0].plaintext == b"Hello from luast"
    assert rep.strings[0].ambiguous is False
    assert rep.branches_folded >= 30
    assert rep.shuffles == 6


def test_output_is_valid_lua_and_matches_original():
    original = (
        'local msg = "Hello from luast"\n'
        "local n = 3\n"
        "for i = 1, n do\n"
        "    print(i, msg)\n"
        "end\n"
    )
    text, _ = deobfuscate(SAMPLE.read_text())
    parse(text)                       # must still be syntactically valid
    try:
        import lupa  # noqa: F401
    except ImportError:
        return
    assert run_lua(text) == run_lua(original)


def test_keep_dead_preserves_more():
    lean, _ = deobfuscate(SAMPLE.read_text())
    fat, _ = deobfuscate(SAMPLE.read_text(), keep_dead=True)
    assert len(fat) > len(lean)
    assert "bit32" in fat and "bit32" not in lean


def test_raw_mode_still_parses():
    text, _ = deobfuscate(SAMPLE.read_text(), do_polish=False)
    parse(text)
    assert "Hello from luast" in text


def test_rejects_non_luast_input():
    try:
        deobfuscate("local x = 1\nprint(x)\n")
    except RuntimeError as exc:
        assert "luast" in str(exc) or "dispatcher" in str(exc)
    else:
        raise AssertionError("should have refused a non-luast script")


if __name__ == "__main__":
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  PASS  {name}")
            except Exception as exc:
                fails += 1
                print(f"  FAIL  {name}: {type(exc).__name__}: {exc}")
    print("\nall green" if not fails else f"\n{fails} failing test(s)")
    raise SystemExit(1 if fails else 0)
